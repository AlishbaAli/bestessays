<!doctype html><html lang="en" xmlns:fb="https://www.facebook.com/2008/fbml"><head><script src="/res_v1560415138/js/js-error-log.js" type="text/javascript"></script><link rel="manifest" href="/../manifest.json"><meta name="msapplication-config" content="/../browserconfig.xml">     <script>
        dataLayer = [{
            'userId': '0'
        }];
    </script>
              
          <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MTC9MMT');</script>
<!-- End Google Tag Manager -->    
          <!--  OneSignal  -->
    <script src="//cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
    <script>
        var OneSignal = OneSignal || [];
        OneSignal.push(["init", {
            appId: "bb0fbb64-603b-44e3-9cc7-50321eb8135c",
            autoRegister: true,
            notifyButton: {
                enable: false /* Set to false to hide */
            },
            safari_web_id: 'web.onesignal.auto.1b5e3a9a-fd8d-4cbc-b150-cc0a98b0f0fe'
        }]);
    </script>
<!--  End OneSignal  -->    
          <meta name="google-site-verification" content="TMIE4J4vH0OJ1VA45i4xMaGBHtJBOk_gBdCT_vxrl_s" />
    
   <title>Professional Admission Paper Editing Help | Best Essays</title>  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>  <meta name="description" content="You need your admission essay edited to perfection? Hire professional editors at our website. The prices are affordable and the results are great!"/>   <meta charset="utf-8"><meta name="viewport" content="width=device-width"><style> @font-face{font-family:Open Sans;font-style:normal;font-weight:300;src:local("Open Sans Light"),local("OpenSans-Light"),url(/styles/fonts/open-sans-v15-latin-300.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-300.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:400;src:local("Open Sans Regular"),local("OpenSans-Regular"),url(/styles/fonts/open-sans-v15-latin-regular.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-regular.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:600;src:local("Open Sans SemiBold"),local("OpenSans-SemiBold"),url(/styles/fonts/open-sans-v15-latin-600.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-600.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:700;src:local("Open Sans Bold"),local("OpenSans-Bold"),url(/styles/fonts/open-sans-v15-latin-700.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-700.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:800;src:local("Open Sans ExtraBold"),local("OpenSans-ExtraBold"),url(/styles/fonts/open-sans-v15-latin-800.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-800.woff) format("woff")}.logo-block .flex-wrapper{-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding:20px}.logo-block .flex-wrapper,.logo-block__support{display:-webkit-box;display:-ms-flexbox;display:flex}.logo-block__support{-webkit-box-align:center;-ms-flex-align:center;align-items:center}.logo-block__support a{display:inline-block;margin-left:10px;padding:5px 30px;border:1px solid #9f88da;text-align:center;color:#fff;border-radius:15px}.fb-messager__link{display:-webkit-box!important;display:-ms-flexbox!important;display:flex!important;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-ms-flex-pack:distribute;justify-content:space-around}.fb-messager__text{margin-bottom:0;color:#fff!important}.fb-messager{width:173px}.logo-block__support a span:before{content:"";display:inline-block;margin-right:2px;vertical-align:middle;margin-top:0;width:7px;height:7px;background:#3dd256;border-radius:50%;margin-left:10px}.logo-block__support a:last-child:before{content:"";display:inline-block;margin-right:10px;background-image:url(/build/37a753b37bab035f53d9561de79c847e.png);background-position:-486px -164px;width:12px;height:17px;vertical-align:middle;margin-top:-5px}.fb-messager__link:before{display:none!important}.logo-block__support a:hover{text-decoration:none;background:#896ebb;-webkit-transition:.4s;transition:.4s}@media (max-width:1200px){.logo-block .flex-wrapper{-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.fb-messager__link{padding:5px 25px!important}}@media (max-width:1024px){.logo-block__logo{display:none}.logo-block .flex-wrapper{-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}}@media (max-width:767px){.logo-block{display:block}.logo-block__support a{padding:5px 20px!important}.logo-block .flex-wrapper{padding:35px 20px 20px}}@media (max-width:670px){.logo-block .flex-wrapper{-ms-flex-pack:distribute;justify-content:space-around}.fb-messager__text{font-size:0}.logo-block__support a span{display:none}.fb-messager{width:62px}.logo-block__support{width:100%;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.logo-block__support a{margin-left:0;padding-left:5px!important;padding-right:5px!important}.fb-messager{-webkit-box-ordinal-group:4;-ms-flex-order:3;order:3}.logo-block__support a:nth-of-type(2){-webkit-box-ordinal-group:2;-ms-flex-order:1;order:1}.logo-block__support a:first-of-type{-webkit-box-ordinal-group:3;-ms-flex-order:2;order:2}.fb-messager__link{padding:5px 25px!important;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.logo-block,.logo-block .flex-wrapper{padding-left:0!important;padding-right:0!important}}.btn-danger,.btn-default,.btn-info,.btn-primary,.btn-success,.btn-warning{text-shadow:0 -1px 0 rgba(0,0,0,.2);-webkit-box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 1px rgba(0,0,0,.075)}.btn-danger.active,.btn-danger:active,.btn-default.active,.btn-default:active,.btn-info.active,.btn-info:active,.btn-primary.active,.btn-primary:active,.btn-success.active,.btn-success:active,.btn-warning.active,.btn-warning:active{-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);box-shadow:inset 0 3px 5px rgba(0,0,0,.125)}.btn.active,.btn:active{background-image:none}.btn-default{text-shadow:0 1px 0 #fff;background-image:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#e0e0e0));background-image:-webkit-linear-gradient(top,#fff,#e0e0e0);background-image:linear-gradient(180deg,#fff 0,#e0e0e0);background-repeat:repeat-x;border-color:#ccc}.btn-default:focus,.btn-default:hover{background-color:#e0e0e0;background-position:0 -15px}.btn-default.active,.btn-default:active{background-color:#e0e0e0;border-color:#dbdbdb}.btn-primary{background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#2d6ca2));background-image:-webkit-linear-gradient(top,#428bca,#2d6ca2);background-image:linear-gradient(180deg,#428bca 0,#2d6ca2);background-repeat:repeat-x;border-color:#2b669a}.btn-primary:focus,.btn-primary:hover{background-color:#2d6ca2;background-position:0 -15px}.btn-primary.active,.btn-primary:active{background-color:#2d6ca2;border-color:#2b669a}.btn-success{background-image:-webkit-gradient(linear,left top,left bottom,from(#5cb85c),to(#419641));background-image:-webkit-linear-gradient(top,#5cb85c,#419641);background-image:linear-gradient(180deg,#5cb85c 0,#419641);background-repeat:repeat-x;border-color:#3e8f3e}.btn-success:focus,.btn-success:hover{background-color:#419641;background-position:0 -15px}.btn-success.active,.btn-success:active{background-color:#419641;border-color:#3e8f3e}.btn-info{background-image:-webkit-gradient(linear,left top,left bottom,from(#5bc0de),to(#2aabd2));background-image:-webkit-linear-gradient(top,#5bc0de,#2aabd2);background-image:linear-gradient(180deg,#5bc0de 0,#2aabd2);background-repeat:repeat-x;border-color:#28a4c9}.btn-info:focus,.btn-info:hover{background-color:#2aabd2;background-position:0 -15px}.btn-info.active,.btn-info:active{background-color:#2aabd2;border-color:#28a4c9}.btn-warning{background-image:-webkit-gradient(linear,left top,left bottom,from(#f0ad4e),to(#eb9316));background-image:-webkit-linear-gradient(top,#f0ad4e,#eb9316);background-image:linear-gradient(180deg,#f0ad4e 0,#eb9316);background-repeat:repeat-x;border-color:#e38d13}.btn-warning:focus,.btn-warning:hover{background-color:#eb9316;background-position:0 -15px}.btn-warning.active,.btn-warning:active{background-color:#eb9316;border-color:#e38d13}.btn-danger{background-image:-webkit-linear-gradient(top,#d9534f,#c12e2a);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9534f),to(#c12e2a));background-image:linear-gradient(180deg,#d9534f 0,#c12e2a);background-repeat:repeat-x;border-color:#b92c28}.btn-danger:focus,.btn-danger:hover{background-color:#c12e2a;background-position:0 -15px}.btn-danger.active,.btn-danger:active{background-color:#c12e2a;border-color:#b92c28}.img-thumbnail,.thumbnail{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.075);box-shadow:0 1px 2px rgba(0,0,0,.075)}.dropdown-menu>li>a:focus,.dropdown-menu>li>a:hover{background-color:#e8e8e8;background-image:-webkit-linear-gradient(top,#f5f5f5,#e8e8e8);background-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#e8e8e8));background-image:linear-gradient(180deg,#f5f5f5 0,#e8e8e8);background-repeat:repeat-x}.dropdown-menu>.active>a,.dropdown-menu>.active>a:focus,.dropdown-menu>.active>a:hover{background-color:#357ebd;background-image:-webkit-linear-gradient(top,#428bca,#357ebd);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#357ebd));background-image:linear-gradient(180deg,#428bca 0,#357ebd);background-repeat:repeat-x}.navbar-default{background-image:-webkit-linear-gradient(top,#fff,#f8f8f8);background-image:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#f8f8f8));background-image:linear-gradient(180deg,#fff 0,#f8f8f8);background-repeat:repeat-x;border-radius:4px;-webkit-box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 5px rgba(0,0,0,.075);box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 5px rgba(0,0,0,.075)}.navbar-default .navbar-nav>.active>a{background-image:-webkit-linear-gradient(top,#ebebeb,#f3f3f3);background-image:-webkit-gradient(linear,left top,left bottom,from(#ebebeb),to(#f3f3f3));background-image:linear-gradient(180deg,#ebebeb 0,#f3f3f3);background-repeat:repeat-x;-webkit-box-shadow:inset 0 3px 9px rgba(0,0,0,.075);box-shadow:inset 0 3px 9px rgba(0,0,0,.075)}.navbar-brand,.navbar-nav>li>a{text-shadow:0 1px 0 hsla(0,0%,100%,.25)}.navbar-inverse{background-image:-webkit-linear-gradient(top,#3c3c3c,#222);background-image:-webkit-gradient(linear,left top,left bottom,from(#3c3c3c),to(#222));background-image:linear-gradient(180deg,#3c3c3c 0,#222);background-repeat:repeat-x}.navbar-inverse .navbar-nav>.active>a{background-image:-webkit-linear-gradient(top,#222,#282828);background-image:-webkit-gradient(linear,left top,left bottom,from(#222),to(#282828));background-image:linear-gradient(180deg,#222 0,#282828);background-repeat:repeat-x;-webkit-box-shadow:inset 0 3px 9px rgba(0,0,0,.25);box-shadow:inset 0 3px 9px rgba(0,0,0,.25)}.navbar-inverse .navbar-brand,.navbar-inverse .navbar-nav>li>a{text-shadow:0 -1px 0 rgba(0,0,0,.25)}.navbar-fixed-bottom,.navbar-fixed-top,.navbar-static-top{border-radius:0}.alert{text-shadow:0 1px 0 hsla(0,0%,100%,.2);-webkit-box-shadow:inset 0 1px 0 hsla(0,0%,100%,.25),0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 hsla(0,0%,100%,.25),0 1px 2px rgba(0,0,0,.05)}.alert-success{background-image:-webkit-linear-gradient(top,#dff0d8,#c8e5bc);background-image:-webkit-gradient(linear,left top,left bottom,from(#dff0d8),to(#c8e5bc));background-image:linear-gradient(180deg,#dff0d8 0,#c8e5bc);background-repeat:repeat-x;border-color:#b2dba1}.alert-info{background-image:-webkit-linear-gradient(top,#d9edf7,#b9def0);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9edf7),to(#b9def0));background-image:linear-gradient(180deg,#d9edf7 0,#b9def0);background-repeat:repeat-x;border-color:#9acfea}.alert-warning{background-image:-webkit-linear-gradient(top,#fcf8e3,#f8efc0);background-image:-webkit-gradient(linear,left top,left bottom,from(#fcf8e3),to(#f8efc0));background-image:linear-gradient(180deg,#fcf8e3 0,#f8efc0);background-repeat:repeat-x;border-color:#f5e79e}.alert-danger{background-image:-webkit-linear-gradient(top,#f2dede,#e7c3c3);background-image:-webkit-gradient(linear,left top,left bottom,from(#f2dede),to(#e7c3c3));background-image:linear-gradient(180deg,#f2dede 0,#e7c3c3);border-color:#dca7a7}.alert-danger,.progress{background-repeat:repeat-x}.progress{background-image:-webkit-linear-gradient(top,#ebebeb,#f5f5f5);background-image:-webkit-gradient(linear,left top,left bottom,from(#ebebeb),to(#f5f5f5));background-image:linear-gradient(180deg,#ebebeb 0,#f5f5f5)}.progress-bar{background-image:-webkit-linear-gradient(top,#428bca,#3071a9);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#3071a9));background-image:linear-gradient(180deg,#428bca 0,#3071a9);background-repeat:repeat-x}.progress-bar-success{background-image:-webkit-linear-gradient(top,#5cb85c,#449d44);background-image:-webkit-gradient(linear,left top,left bottom,from(#5cb85c),to(#449d44));background-image:linear-gradient(180deg,#5cb85c 0,#449d44);background-repeat:repeat-x}.progress-bar-info{background-image:-webkit-linear-gradient(top,#5bc0de,#31b0d5);background-image:-webkit-gradient(linear,left top,left bottom,from(#5bc0de),to(#31b0d5));background-image:linear-gradient(180deg,#5bc0de 0,#31b0d5);background-repeat:repeat-x}.progress-bar-warning{background-image:-webkit-linear-gradient(top,#f0ad4e,#ec971f);background-image:-webkit-gradient(linear,left top,left bottom,from(#f0ad4e),to(#ec971f));background-image:linear-gradient(180deg,#f0ad4e 0,#ec971f);background-repeat:repeat-x}.progress-bar-danger{background-image:-webkit-linear-gradient(top,#d9534f,#c9302c);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9534f),to(#c9302c));background-image:linear-gradient(180deg,#d9534f 0,#c9302c);background-repeat:repeat-x}.list-group{border-radius:4px;-webkit-box-shadow:0 1px 2px rgba(0,0,0,.075);box-shadow:0 1px 2px rgba(0,0,0,.075)}.list-group-item.active,.list-group-item.active:focus,.list-group-item.active:hover{text-shadow:0 -1px 0 #3071a9;background-image:-webkit-linear-gradient(top,#428bca,#3278b3);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#3278b3));background-image:linear-gradient(180deg,#428bca 0,#3278b3);background-repeat:repeat-x;border-color:#3278b3}.panel{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.05);box-shadow:0 1px 2px rgba(0,0,0,.05)}.panel-default>.panel-heading{background-image:-webkit-linear-gradient(top,#f5f5f5,#e8e8e8);background-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#e8e8e8));background-image:linear-gradient(180deg,#f5f5f5 0,#e8e8e8);-webkit-filter:progid:DXImageTransfzorm.Microsoft.gradient(startColorstr="#fff5f5f5",endColorstr="#ffe8e8e8",GradientType=0);background-repeat:repeat-x}.panel-primary>.panel-heading{background-image:-webkit-linear-gradient(top,#428bca,#357ebd);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#357ebd));background-image:linear-gradient(180deg,#428bca 0,#357ebd);background-repeat:repeat-x}.panel-success>.panel-heading{background-image:-webkit-linear-gradient(top,#dff0d8,#d0e9c6);background-image:-webkit-gradient(linear,left top,left bottom,from(#dff0d8),to(#d0e9c6));background-image:linear-gradient(180deg,#dff0d8 0,#d0e9c6);background-repeat:repeat-x}.panel-info>.panel-heading{background-image:-webkit-linear-gradient(top,#d9edf7,#c4e3f3);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9edf7),to(#c4e3f3));background-image:linear-gradient(180deg,#d9edf7 0,#c4e3f3);background-repeat:repeat-x}.panel-warning>.panel-heading{background-image:-webkit-linear-gradient(top,#fcf8e3,#faf2cc);background-image:-webkit-gradient(linear,left top,left bottom,from(#fcf8e3),to(#faf2cc));background-image:linear-gradient(180deg,#fcf8e3 0,#faf2cc);background-repeat:repeat-x}.panel-danger>.panel-heading{background-image:-webkit-linear-gradient(top,#f2dede,#ebcccc);background-image:-webkit-gradient(linear,left top,left bottom,from(#f2dede),to(#ebcccc));background-image:linear-gradient(180deg,#f2dede 0,#ebcccc);background-repeat:repeat-x}.well{background-image:-webkit-linear-gradient(top,#e8e8e8,#f5f5f5);background-image:-webkit-gradient(linear,left top,left bottom,from(#e8e8e8),to(#f5f5f5));background-image:linear-gradient(180deg,#e8e8e8 0,#f5f5f5);background-repeat:repeat-x;border-color:#dcdcdc;-webkit-box-shadow:inset 0 1px 3px rgba(0,0,0,.05),0 1px 0 hsla(0,0%,100%,.1);box-shadow:inset 0 1px 3px rgba(0,0,0,.05),0 1px 0 hsla(0,0%,100%,.1)}html{font-family:sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}article,aside,details,figcaption,figure,footer,header,hgroup,main,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block;vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}a:active,a:hover{outline:0}abbr[title]{border-bottom:1px dotted}b,optgroup,strong{font-weight:700}dfn{font-style:italic}h1{margin:.67em 0}mark{color:#000;background:#ff0}small{font-size:80%}sub,sup{position:relative;font-size:75%;line-height:0;vertical-align:baseline}sup{top:-.5em}sub{bottom:-.25em}img{border:0;vertical-align:middle}svg:not(:root){overflow:hidden}hr{height:0;-webkit-box-sizing:content-box;box-sizing:content-box}pre,textarea{overflow:auto}code,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}button,input,optgroup,select,textarea{margin:0;font:inherit;color:inherit}button{overflow:visible}button,select{text-transform:none}button,html input[type=button],input[type=reset],input[type=submit]{-webkit-appearance:button;cursor:pointer}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}input{line-height:normal}input[type=checkbox],input[type=radio]{-webkit-box-sizing:border-box;box-sizing:border-box;padding:0}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{height:auto}input[type=search]{-webkit-box-sizing:content-box;box-sizing:content-box;-webkit-appearance:textfield}input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration{-webkit-appearance:none}fieldset{padding:.35em .625em .75em;margin:0 2px;border:1px solid silver}legend{padding:0;border:0}table{border-spacing:0;border-collapse:collapse}td,th{padding:0}@media print{*{color:#000!important;text-shadow:none!important;background:0 0!important;-webkit-box-shadow:none!important;box-shadow:none!important}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}a[href^="#"]:after,a[href^="javascript:"]:after{content:""}blockquote,pre{border:1px solid #999;page-break-inside:avoid}thead{display:table-header-group}img,tr{page-break-inside:avoid}img{max-width:100%!important}h2,h3,p{orphans:3;widows:3}h2,h3{page-break-after:avoid}select{background:#fff!important}.navbar{display:none}.table td,.table th{background-color:#fff!important}.btn>.caret,.dropup>.btn>.caret{border-top-color:#000!important}.label{border:1px solid #000}.table{border-collapse:collapse!important}.table-bordered td,.table-bordered th{border:1px solid #ddd!important}}*,:after,:before{-webkit-box-sizing:border-box;box-sizing:border-box}html{font-size:62.5%;-webkit-tap-highlight-color:transparent}body{margin:0;font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff}button,input,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit}a{background:0 0;color:#428bca;text-decoration:none}a:focus,a:hover{color:#2a6496;text-decoration:underline}a:focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}figure{margin:0}.carousel-inner>.item>a>img,.carousel-inner>.item>img,.img-responsive,.thumbnail>img,.thumbnail a>img{display:block;max-width:100%;height:auto}.img-rounded{border-radius:6px}.img-thumbnail{display:inline-block;max-width:100%;height:auto;padding:4px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:.2s ease-in-out;transition:.2s ease-in-out}.img-circle{border-radius:50%}hr{margin-top:20px;margin-bottom:20px;border:0;border-top:1px solid #eee}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{font-family:inherit;font-weight:500;line-height:1.1;color:inherit}.h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,.h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{font-weight:400;line-height:1;color:#999}.h1,.h2,.h3,h1,h2,h3{margin-top:20px;margin-bottom:10px}.h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small{font-size:65%}.h4,.h5,.h6,h4,h5,h6{margin-top:10px;margin-bottom:10px}.h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{font-size:75%}.h1,h1{font-size:36px}.h2,h2{font-size:30px}.h3,h3{font-size:24px}.h4,h4{font-size:18px}.h5,h5{font-size:14px}.h6,h6{font-size:12px}p{margin:0 0 10px} </style><script src="/js_v1560415138/adaptive/jquery1.10.js"></script><script src="/js_v1560415138/adaptive/index.js"></script><script src="/js_v1560415138/adaptive/bootstrap.min.js"></script>  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>  <script src="/scripts_v1560415138/tooltip/jquery.dimensions.js"></script>  <script src="/scripts_v1560415138/tooltip/jquery.tooltip.js"></script>  <script src="/scripts_v1560415138/tooltip/chili-1.7.pack.js"></script>  <script src="/js_v1560415138/adaptive/jquery.selectbox-0.2.js"></script><!--[if lte IE 9]>
    <script src="/js_v1560415138/adaptive/html5.js"></script>
    <script src="/js_v1560415138/adaptive/html5shiv.js"></script>
    <script src="/js_v1560415138/adaptive/respond.js"></script>
    <script src="/js_v1560415138/adaptive/ie-bootstrap-carousel.js"></script>
    <![endif]--><!--[if IE 8]>
    <link href="/styles_v1560415138/adaptive/ie8.css" rel="stylesheet" media="all"/><![endif]--><!--[if IE 7]>
    <link href="/styles_v1560415138/adaptive/ie7.css" rel="stylesheet" media="all"/><![endif]-->  <!--[if gt IE 7]>
    <link href="/styles_v1560415138/style_ie_all.css" media="screen" rel="stylesheet" type="text/css"/>
    <![endif]--><!--[if lt IE 7]>
    <link href="/styles_v1560415138/style_ie6.css" media="screen" rel="stylesheet" type="text/css"/>
    <script async src="/scripts_v1560415138/dd_belatedpng.js" type="text/javascript"></script>
    <script async type="text/javascript">DD_belatedPNG.fix("img, div, a, span, ul, p, input");</script>
    <![endif]--><!--[if IE]>
    <style type="text/css">.titleExtras, a.use, a.use span {
        behavior: url(/styles/PIE.htc);</style>
    <![endif]--><!--[if IE 6]>
    <script async src="scripts/DD_belatedPNG.js" async></script>
    <script async type="text/javascript">DD_belatedPNG.fix(".live_supp, .leftmenu li a, .girl");</script>
    <![endif]--><script>!function(e,t,n,c,o,a,f){e.fbq||(o=e.fbq=function(){o.callMethod?o.callMethod.apply(o,arguments):o.queue.push(arguments)},e._fbq||(e._fbq=o),(o.push=o).loaded=!0,o.version="2.0",o.queue=[],(a=t.createElement(n)).async=!0,a.src="https://connect.facebook.net/en_US/fbevents.js",(f=t.getElementsByTagName(n)[0]).parentNode.insertBefore(a,f))}(window,document,"script"),fbq("init","1706090589711754"),fbq("track","PageView")</script><noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1706090589711754&ev=PageView&noscript=1"/></noscript><link rel="apple-touch-icon" sizes="57x57" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-57x57.png"><link rel="apple-touch-icon" sizes="60x60" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-60x60.png"><link rel="apple-touch-icon" sizes="72x72" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-72x72.png"><link rel="apple-touch-icon" sizes="76x76" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-76x76.png"><link rel="apple-touch-icon" sizes="114x114" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-114x114.png"><link rel="apple-touch-icon" sizes="120x120" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-120x120.png"><link rel="apple-touch-icon" sizes="144x144" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-144x144.png"><link rel="apple-touch-icon" sizes="152x152" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-152x152.png"><link rel="apple-touch-icon" sizes="180x180" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-180x180.png"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="bestessays.com"><meta name="mobile-web-app-capable" content="yes"><meta name="theme-color" content="#fff"><meta name="application-name" content="bestessays.com"><link rel="icon" type="image/png" sizes="32x32" href="/build/icons-2ff7e2b756984cf0927329a004210003/favicon-32x32.png"><link rel="icon" type="image/png" sizes="16x16" href="/build/icons-2ff7e2b756984cf0927329a004210003/favicon-16x16.png"><link rel="shortcut icon" href="/build/icons-2ff7e2b756984cf0927329a004210003/favicon.ico"><link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 1)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-320x460.png"><link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-640x920.png"><link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-640x1096.png"><link rel="apple-touch-startup-image" media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-750x1294.png"><link rel="apple-touch-startup-image" media="(device-width: 414px) and (device-height: 736px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 3)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1182x2208.png"><link rel="apple-touch-startup-image" media="(device-width: 414px) and (device-height: 736px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 3)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1242x2148.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 1)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-748x1024.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 1)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-768x1004.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1496x2048.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1536x2008.png"><link href="/build/adaptive.3dba1394b914ec12b317.bundle.css" rel="stylesheet"><link rel="preload" href="/build/adaptive.3dba1394b914ec12b317.bundle.css" as="style"></head><body><div id="fb-root"></div><script>!function(e,t,n){var c,o=e.getElementsByTagName(t)[0];e.getElementById(n)||((c=e.createElement(t)).id=n,c.src="//connect.facebook.net/ru_RU/all.js#xfbml=1",o.parentNode.insertBefore(c,o))}(document,"script","facebook-jssdk")</script><div class="login_layer"><div class="container"><div class="login_container"><div class="title-login mobile">Please, login</div><form id="loginbox" method="post" action="/customer/login/" class="login_form"><div class="cancel"></div><div class="input text"><label><span>Login:</span><br/><input id="login_email" name="email"></label></div><div class="input text"><label><span>Password:</span><br/></label> <input type="password" id="pass" name="pass"></div><input name="remember_me" id="remember_me" type="checkbox" checked="checked"><label for="remember_me" class="remember_me_label">Remember me</label><div class="login_button"><a href="/forgot.html">Forgot password?</a> <button onclick='checkform(document.getElementById("loginbox"))' class="button" type="submit">Login</button></div></form></div></div></div><header><div class="mobile mobile-logo"><a href="/"><img src="/images/customer/mobile-logo.png" alt="BestEssays"></a></div><nav class="hi_top_menu"><div class="mobile-btn mobile-menu"></div><div class="container"><ul class="clearfix"><div class="pull-left-mobile"><li><a href="/">Home</a></li><li><a href="/our-services.php">Services</a></li><li><a href="/prices.php">Prices</a></li><li><a href="/order">Order</a></li><li><a href="/get-great-discounts.php">Discounts</a></li><li class="hidden-xs"><a href="/samples.php">Samples</a></li><li class="hidden-xs"><a href="/aboutus.php">About Us</a></li><li class="hidden-xs"><a href="/customersupport.php">Contacts</a></li></div><div class="pull-right">  <a href="javascript:void(0)" class="button login_opener">Login</a>  </div></ul><div class="mobile-close">X</div></div>  <div class="mobile-btn mobile-login"></div>  </nav><div class="container logo-block">          <div class="logo-block">
    <div class="center-wrapper">
        <div class="flex-wrapper">
            <div class="logo-block__logo">
                <a href="/">
                    <img src="/images/img-home/split/logo.png" alt="">
                </a>
            </div>
            <div class="logo-block__support">
                <div class="fb-messager">
                    <a class="fb-messager__link" href="https://m.me/bestessayscom" target="_blank">
                        <img class="fb-messager__img" src="//img2.bestessays.com/buttons/facebook-messenger-1%401X.png">
                        <p class="fb-messager__text">Message us</p>
                    </a>
                </div>
                <a href="#" onclick="chat = document.querySelector('.bc-minimize-state');!!chat?chat.click():document.querySelector('.bcFloat a').click();return false;">Live Chat <span> online</span></a>
                <a href="tel:+1-888-533-4942">+1-888-533-4942</a>
            </div>
        </div>
    </div>
</div>    
 
<nav class="main_menu">
	<ul class="topmenu">
														<li class="first" >
				<a href="/doc_essay.php"><span>Essay</span></a>

				</li>
																	<li  >
				<a href="/custom_research_paper.php"><span>Research<br>Paper</span></a>

				</li>
																	<li  >
				<a href="/coursework.php"><span>Coursework</span></a>

				</li>
																	<li  >
				<a href="/custom_term_paper.php"><span>Term Paper</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/casestudy.php"><span>Case Study</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/dissertation-services.php"><span>Dissertation Services</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/admission-application-essay.php"><span>Admission<br>Services</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="https://www.resumesplanet.com" rel="nofollow"><span>Resume</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/extras.php"><span>Extras</span></a>

				</li>
																																																																	        <li class="hidden-sm hidden-md hidden-lg">
            <a href="/our-services.php">More</a>
        </li>
	</ul>
</nav>

         <style>
.firstTime#dynamicBanner{
background:url("//img2.bestessays.com/ukfacebook/bg_block_new.png") no-repeat;
}
.mainBanner{
max-width:720px!important;
padding-right:0!important;
}
</style>    
 </div></header><div id="body_content"><div class="content">  <section class="container pt_container">
<h1>Get professional help with any type of admission essay editing writing</h1>
</section>      <div class="container pt_tables">

<div id="price-area">
        

<div id="prices_table_content">
    <div class="filter clearfix">
        <div>
            <div class="td_name">Product:</div>
            <div>
                                    Admission Services - Editing                    <input type="hidden" value="145" name="doctype_id" id="set-doctype"/>
                            </div>
        </div>
        <div class="currency_wrapper">
            <div class="td_name">Currency:</div>
            <div>
                <div class="currency_but clearfix">
                    <a href="javascript:changeCurrency('USD');">USD</a>
                    <a href="javascript:changeCurrency('GBP');">GBP</a>
                    <a href="javascript:changeCurrency('AUD');">AUD</a>
                    <a class="last" href="javascript:changeCurrency('EUR');">EUR</a>
                </div>
            </div>
        </div>

                    <div>
                <div class="td_name">Subject area:</div>
                <div>
                    <select name="category_id" class="filter_inp" id="set-category" onchange="doUpdatePrices()">
                        <option value="0">select</option><option value="10">Art</option><option value="12">&nbsp;&nbsp;Architecture</option><option value="15">&nbsp;&nbsp;Dance</option><option value="17">&nbsp;&nbsp;Design Analysis</option><option value="13">&nbsp;&nbsp;Drama</option><option value="16">&nbsp;&nbsp;Movies</option><option value="18">&nbsp;&nbsp;Music</option><option value="11">&nbsp;&nbsp;Paintings</option><option value="14">&nbsp;&nbsp;Theatre</option><option value="112">Biology</option><option value="52">Business</option><option value="111">Chemistry</option><option value="102">Communications and Media</option><option value="105">&nbsp;&nbsp;Advertising</option><option value="107">&nbsp;&nbsp;Communication Strategies</option><option value="103">&nbsp;&nbsp;Journalism</option><option value="104">&nbsp;&nbsp;Public Relations</option><option value="53">Economics</option><option value="60">&nbsp;&nbsp;Accounting</option><option value="58">&nbsp;&nbsp;Company Analysis</option><option value="62">&nbsp;&nbsp;E-Commerce</option><option value="59">&nbsp;&nbsp;Finance</option><option value="117">&nbsp;&nbsp;International Affairs/Relations</option><option value="57">&nbsp;&nbsp;Investment</option><option value="63">&nbsp;&nbsp;Logistics</option><option value="64">&nbsp;&nbsp;Trade</option><option value="87">Education</option><option value="93">&nbsp;&nbsp;Application Essay</option><option value="89">&nbsp;&nbsp;Education Theories</option><option value="88">&nbsp;&nbsp;Pedagogy</option><option value="90">&nbsp;&nbsp;Teacher's Career</option><option value="67">Engineering</option><option value="9">English</option><option value="24">Ethics</option><option value="36">History</option><option value="38">&nbsp;&nbsp;African-American Studies</option><option value="37">&nbsp;&nbsp;American History</option><option value="42">&nbsp;&nbsp;Asian Studies</option><option value="41">&nbsp;&nbsp;Canadian Studies</option><option value="44">&nbsp;&nbsp;East European Studies</option><option value="45">&nbsp;&nbsp;Holocaust</option><option value="40">&nbsp;&nbsp;Latin-American Studies</option><option value="39">&nbsp;&nbsp;Native-American Studies</option><option value="43">&nbsp;&nbsp;West European Studies</option><option value="47">Law</option><option value="49">&nbsp;&nbsp;Criminology</option><option value="48">&nbsp;&nbsp;Legal Issues</option><option value="7">Linguistics</option><option value="2">Literature</option><option value="4">&nbsp;&nbsp;American Literature</option><option value="5">&nbsp;&nbsp;Antique Literature</option><option value="6">&nbsp;&nbsp;Asian Literature</option><option value="3">&nbsp;&nbsp;English Literature</option><option value="116">&nbsp;&nbsp;Shakespeare Studies</option><option value="54">Management</option><option value="56">Marketing</option><option value="51">Mathematics</option><option value="94">Medicine and Health</option><option value="99">&nbsp;&nbsp;Alternative Medicine</option><option value="97">&nbsp;&nbsp;Healthcare</option><option value="101">&nbsp;&nbsp;Nursing</option><option value="95">&nbsp;&nbsp;Nutrition</option><option value="100">&nbsp;&nbsp;Pharmacology</option><option value="96">&nbsp;&nbsp;Sport</option><option value="78">Nature</option><option value="85">&nbsp;&nbsp;Agricultural Studies</option><option value="113">&nbsp;&nbsp;Anthropology</option><option value="86">&nbsp;&nbsp;Astronomy</option><option value="83">&nbsp;&nbsp;Environmental Issues</option><option value="79">&nbsp;&nbsp;Geography</option><option value="80">&nbsp;&nbsp;Geology</option><option value="28">Philosophy</option><option value="110">Physics</option><option value="29">Political Science</option><option value="21">Psychology</option><option value="108">Religion and Theology</option><option value="22">Sociology</option><option value="139">Statistics</option><option value="65">Technology</option><option value="71">&nbsp;&nbsp;Aeronautics</option><option value="70">&nbsp;&nbsp;Aviation</option><option value="72">&nbsp;&nbsp;Computer Science</option><option value="73">&nbsp;&nbsp;Internet</option><option value="75">&nbsp;&nbsp;IT Management</option><option value="77">&nbsp;&nbsp;Web Design</option><option value="114">Tourism</option>                    </select>
                </div>
            </div>
                <div>
            <div class="td_name">Number of pages:</div>
            <div>
                                    <input type="text" name="pages_count" id="pages_count" value="1" onkeyup="doUpdatePrices();" onblur="if(this.value == ''){this.value = 1;doUpdatePrices();}" class="filter_inp" />
                            </div>
        </div>
                    <div id="filter_num_papers">
                <div class="td_name">Number of papers:</div>
                <div>
                    <input type="text" name="papers_count" id="papers_count" onkeyup="doUpdatePrices();" onblur="if(this.value == ''){this.value = 1;doUpdatePrices();}" value="1" class="filter_inp" />
                </div>
            </div>
        
    </div>
</div>
<div class="clearfix"></div>
<div id="for_prices">
    <table class="prices" cellspacing="0" cellpadding=0 id="prices" border="0" width="100%" >
        <tr>
            <th class="th_null " style="width:77px;">
                				&nbsp;
				            </th>
                                    <th class="price_title1">
                <div class="price_title-block">
                    College
                                    </div>
            </th>
                        <th class="price_title2 best_choise_wrlevel">
                <div class="price_title-block">
                    Graduate
                                            <div class="price_aw"></div>
                                    </div>
            </th>
                        <th class="price_title3">
                <div class="price_title-block">
                    Business, Law, Medical Schools
                                    </div>
            </th>
                    </tr>

                          <tr class="">
            <td class="td_name">10 days</td>
                        <td id="val-11-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=11&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>12.95                </a>
            </td>
                        <td id="val-11-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=11&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>13.95                </a>
            </td>
                        <td id="val-11-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=11&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>13.95                </a>
            </td>
                                            </tr>
                  <tr class="td_null">
            <td class="td_name">7 days</td>
                        <td id="val-1-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=1&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>13.95                </a>
            </td>
                        <td id="val-1-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=1&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>14.95                </a>
            </td>
                        <td id="val-1-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=1&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>14.95                </a>
            </td>
                                            </tr>
                  <tr class="">
            <td class="td_name">4 days</td>
                        <td id="val-4-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=4&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>14.95                </a>
            </td>
                        <td id="val-4-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=4&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>15.95                </a>
            </td>
                        <td id="val-4-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=4&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>15.95                </a>
            </td>
                                            </tr>
                  <tr class="td_null">
            <td class="td_name">3 days</td>
                        <td id="val-5-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=5&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>15.95                </a>
            </td>
                        <td id="val-5-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=5&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>16.95                </a>
            </td>
                        <td id="val-5-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=5&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>16.95                </a>
            </td>
                                            </tr>
                  <tr class="">
            <td class="td_name">48 hours</td>
                        <td id="val-6-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=6&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>16.95                </a>
            </td>
                        <td id="val-6-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=6&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>17.95                </a>
            </td>
                        <td id="val-6-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=6&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>17.95                </a>
            </td>
                                            </tr>
                  <tr class="td_null">
            <td class="td_name">24 hours</td>
                        <td id="val-7-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=7&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>21.95                </a>
            </td>
                        <td id="val-7-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=7&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>22.95                </a>
            </td>
                        <td id="val-7-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=7&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>22.95                </a>
            </td>
                                            </tr>
                  <tr class="">
            <td class="td_name">12 hours</td>
                        <td id="val-8-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=8&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>22.95                </a>
            </td>
                        <td id="val-8-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=8&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>23.95                </a>
            </td>
                        <td id="val-8-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=8&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>23.95                </a>
            </td>
                                            </tr>
                  <tr class="td_null">
            <td class="td_name">6 hours</td>
                        <td id="val-9-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=9&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>23.95                </a>
            </td>
                        <td id="val-9-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=9&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>24.95                </a>
            </td>
                        <td id="val-9-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=9&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>24.95                </a>
            </td>
                                            </tr>
                  <tr class="">
            <td class="td_name">3 hours</td>
                        <td id="val-10-1" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=10&wrlevel=1&curr=USD">
                    <span class="ptable_curr">$</span>25.95                </a>
            </td>
                        <td id="val-10-2" class="dark">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=10&wrlevel=2&curr=USD">
                    <span class="ptable_curr">$</span>26.95                </a>
            </td>
                        <td id="val-10-116" class="light">
                <a rel="" class="tooltip with_ff" href="/order.php?doctype=145&urgency=10&wrlevel=116&curr=USD">
                    <span class="ptable_curr">$</span>26.95                </a>
            </td>
                                            </tr>
            </table>
    </div>

<script type="text/javascript">
    var  uids = [1,4,5,6,7,8,9,10,11];
    var  wlids = [1,2,116];
    var  urgencies_json = {"240_":{"id":"11","name":"10 days"},"168_":{"id":"1","name":"7 days"},"96_":{"id":"4","name":"4 days"},"72_":{"id":"5","name":"3 days"},"48_":{"id":"6","name":"48 hours"},"24_":{"id":"7","name":"24 hours"},"12_":{"id":"8","name":"12 hours"},"6_":{"id":"9","name":"6 hours"},"3_":{"id":"10","name":"3 hours"}};
    var  wrlevels_json = {"1":"College","2":"Graduate","116":"Business, Law, Medical Schools"};
    var  plist = {"1":{"1":13.95,"2":14.95,"116":14.95},"4":{"1":14.95,"2":15.95,"116":15.95},"5":{"1":15.95,"2":16.95,"116":16.95},"6":{"1":16.95,"2":17.95,"116":17.95},"7":{"1":21.95,"2":22.95,"116":22.95},"8":{"1":22.95,"2":23.95,"116":23.95},"9":{"1":23.95,"2":24.95,"116":24.95},"10":{"1":25.95,"2":26.95,"116":26.95},"11":{"1":12.95,"2":13.95,"116":13.95}};
    var  free_feature_list = {"1":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"15":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"40":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"146":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"147":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"148":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"149":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"150":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"151":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"172":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"0":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"13":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"14":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"37":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"38":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"39":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"80":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]},"11":{"28":["231"],"29":["231"]}},"83":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]},"11":{"28":["231"],"29":["231"]}},"84":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"85":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"234":{"5":{"2":["232"],"28":["231"],"29":["232"]},"7":{"2":["231"],"29":["231"]},"1":{"28":["232"]},"11":{"30":["231"],"29":["231"]}},"168":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"169":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"170":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]}},"171":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"173":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]}},"242":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}}};
    var  free_feature_description = {"183":"\u003Cstrong class=\u0027vas_free\u0027\u003EFREE:\u003C\/strong\u003E VIP Support is included","187":"\u003Cstrong class=\u0027vas_free\u0027\u003EFREE:\u003C\/strong\u003E your order is proofread by an editor","185":"\u003Cstrong class=\u0027vas_free\u0027\u003EFREE:\u003C\/strong\u003E your order is prepared by one of the top 10 writers in your subject area","231":"The most popular choice","232":"The best value"};
    var  free_feature_description_discount = {"183":"\u003Cstrong class=\u0027vas_free\u0027\u003EVIP SUPPORT WITH 50% OFF \u003C\/strong\u003E","187":"\u003Cstrong class=\u0027vas_free\u0027\u003EPROOFREADING WITH 75% OFF:\u003C\/strong\u003E Pay 75% less for your completed paper being proofread by an editor","185":"\u003Cstrong class=\u0027vas_free\u0027\u003ETOP 10 WRITERS WITH 70% OFF:\u003C\/strong\u003E Pay 70% less for your paper being written by one of the Top 10 Writers in your subject","231":"The most popular choice","232":"The best value"};
    var  dt = 145;
    var  multiGroupPrices = null;
    var  show_discount_text_always = '';
    var  number_of_applications_limit = 20;
    var  urgencies_json_indices = ["240_","168_","96_","72_","48_","24_","12_","6_","3_"];
</script>
<script type="text/javascript">
var limitList = new Array();
limitList[145] = {"1":{"5":"60","6":"30","7":"18","8":"12","9":"6","10":"4"},"2":{"5":"60","6":"30","7":"18","8":"12","9":"6","10":"4"},"116":{"5":"60","6":"30","7":"18","8":"12","9":"6","10":"4"}}
var slidesLimitList = new Array();
slidesLimitList[145] = {"1":{"5":"0","6":"0","7":"0","8":"0","9":"0","10":"0"},"2":{"5":"0","6":"0","7":"0","8":"0","9":"0","10":"0"},"116":{"5":"0","6":"0","7":"0","8":"0","9":"0","10":"0"}};
</script>
<script>
    $(document).ready(function(){
        var pages_count = $('#pages_count');

        pages_count.keydown(function(eventObject){
            if(eventObject.which == 8 && pages_count.val() == 0) {
                pages_count.val(1);
                doUpdatePrices();
            }
        });
    })
    if(window.navigator.platform.indexOf('PlayStation') > -1) {
        setInterval(function(){
            var numpages = (document.getElementById('pages_count')) ? +document.getElementById('pages_count').value : false,
                numpapers = (document.getElementById('papers_count')) ? +document.getElementById('papers_count').value : false;
            if (numpages && numpages > 200) {
                doUpdatePrices();
            } else if (numpapers && numpapers > 200) {
                doUpdatePrices();
            } else {
                return;
            }
        }, 100);
    }
</script>

        <div class="level_table_wrapper" >
        <div id="level_table">
            <table>
                <thead>
                <tr>
                    <th class="lt_0_1">&nbsp;</th>
                    <th class="lt_0_2">Standard</th>
                    <th class="lt_0_3">Premium</th>
                    <th class="lt_0_4">Platinum</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th class="lt_col_1">
                        Writer background
                        <a title="Stands for an academic degree held by writers serving a specific writer's level" class="field_hint" href="javascript:void(0);"><img alt="?" src="/images/adaptive/tooltip.png"></a>
                    </th>
                    <td class="lt_col_2">
                        MA
                    </td>
                    <td class="lt_col_3">
                        MA/PhD
                    </td>
                    <td class="lt_col_4">
                        MA/PhD
                    </td>
                </tr>
                <tr>
                    <th class="lt_col_1">
                        FREE add-ons
                        <a title="You get a bibliography, title page, formatting, outline and amendments for FREE" class="field_hint" href="javascript:void(0);"><img alt="?" src="/images/adaptive/tooltip.png"></a>
                    </th>
                    <td class="lt_col_2">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                    <td class="lt_col_3">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                    <td class="lt_col_4">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                </tr>
                <tr>
                    <th class="lt_col_1">
                        Plagiarism check
                        <a title="Plagiarism check of every paper" class="field_hint" href="javascript:void(0);"><img alt="?" src="/images/adaptive/tooltip.png"></a>
                    </th>
                    <td class="lt_col_2">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                    <td class="lt_col_3">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                    <td class="lt_col_4">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                </tr>
                <tr>
                    <th class="lt_col_1">
                        High priority order
                        <a title="With the high priority status, your order will be the first in line to get assigned to an expert" class="field_hint" href="javascript:void(0);"><img alt="?" src="/images/adaptive/tooltip.png"></a>
                    </th>
                    <td class="lt_col_2">
                        —
                    </td>
                    <td class="lt_col_3">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                    <td class="lt_col_4">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                </tr>
                <tr>
                    <th class="lt_col_1">
                        Advanced plagiarism check
                        <a title="Your paper is checked for plagiarism with multiple tools. First, we check it with our own tool, then it's checked with external service" class="field_hint" href="javascript:void(0);"><img alt="?" src="/images/adaptive/tooltip.png"></a>
                    </th>
                    <td class="lt_col_2">
                        —
                    </td>
                    <td class="lt_col_3">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                    <td class="lt_col_4">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                </tr>
                <tr>
                    <th class="lt_col_1">
                        Writer with 5+ years of experience
                        <a title="A writer with 5+ years of experience in academic writing is assigned to your order" class="field_hint" href="javascript:void(0);"><img alt="?" src="/images/adaptive/tooltip.png"></a>
                    </th>
                    <td class="lt_col_2">
                        —
                    </td>
                    <td class="lt_col_3">
                        —
                    </td>
                    <td class="lt_col_4">
                        <img src="/images/adaptive/tick_bbg.png" alt="yes" width="18" height="18">
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
<link rel="stylesheet" href="/res_v1560415138/css/select2/select2.min.css">
<script src="/res_v1560415138/js/select2/select2.js"></script>

<script>

var jQuery = jQuery;
var flag = false;




jQuery( document ).ready(function($) {

        var orderFields = [
            'set-doctype',
            'set-category',
            'pages_count'
        ];

        function filterSelectOptions () {
            $(orderFields).each(function(el,i){

                if($('#' + this).length && $('#' + this).prop("tagName").toLowerCase() === 'select'){
                    $('#' + this).select2();
                }
            });
        }


        filterSelectOptions();

        if(flag){
            $('#set-doctype').bind('change', PriceTable.onChangeDoctype)
        }


        function getTooltip(){

            $('.tooltip').each(function(){

                var rel = $(this).attr('rel');

                if(rel === undefined) return;

                $(this).append('<div class="tooltip-wrap">'+rel+'</div>')

            })
        }

         function addEvenTooltip(){
            $('.tooltip').hover(function(){
                $( this ).toggleClass( "active" );
            })
        }


        setTimeout(function(){

            if(typeof tooltip == 'undefined'){
                getTooltip()
                addEvenTooltip()
            }

        },500)


});

</script>

<style>
    /*#set-doctype,*/
    /*#set-category{*/
        /*display: block !important;*/
    /*}*/

    .tooltip-wrap{
        position:absolute;
        background: #fff;
        padding: 5px;
        color:#333;
        display: none;
        z-index: 1000;
        box-shadow: 0px 0px 7px rgba(0,0,0, .3);
        left: 0;
        width: 100%;
        box-sizing: border-box;
        line-height: 1.2;
        font-size: 12px;
    }
    .tooltip:hover .tooltip-wrap{
        display: block;
    }
    .tooltip-wrap img{
        display: none;
    }
    .tooltip.active{
        z-index: 1050;
    }

    /*#price-area .select2-container .select2-choice{*/
        /*background: none;*/
        /*border: none ;*/
        /*background: none ;*/
        /*box-shadow: none;*/
        /*padding: 5px 7px;*/
    /*}*/
    /*#price-area .select2-container{*/
        /*padding: 0 ;*/
    /*}*/
    /*.select2-container .select2-choice .select2-arrow b {*/
        /*position: relative;*/
        /*top: 48%;*/
    /*}*/
    /*#price-area .select2-container .select2-choice .select2-arrow{*/
    /*display: none;*/
    /*}*/
</style>

</div>

<script type="text/javascript">
    var currency = 'USD';
    var show_tooltip = true;
            var use_js_link = false;
        var cur_gap = '';

    function showBuy(elementObj){
        key = $(elementObj).attr('class').replace('pcolum_', '');
        $('#th_product_title' + key).addClass('price_table_th_active');
        $(elementObj).find('.price_tb_buy').css('display','inline');
    }
    function hideBuy(elementObj){
        key = $(elementObj).attr('class').replace('pcolum_', '');
        $('#th_product_title' + key).removeClass('price_table_th_active');
        $(elementObj).find('.price_tb_buy').css('display','none');
    }

    $(document).ready(function(){
        PriceTable.init();
        doUpdatePrices();
        /* @todo: delete doUpdatePrices() from sites tpl */
    });

    var PriceTable = {
        promoCodes : {},
        init : function()
        {
            PriceTable.initEvents();
            doUpdateFeatures();
            doUpdateQuality();
            PriceTable.reloadTooltip();
            $('.currency_but a').each(function() {
                if($(this).text() == currency)
                    $(this).addClass('active');
            });

            setTimeout(PriceTable.setImgPricesTable,0)

            setTimeout(PriceTable.reloadTooltip,0)

        },
        setImgPricesTable : function(){
            function getNum(str){
                      var r, re;
                      re = /\D+/ig;
                      r = str.replace(re, '');
                      return(r);
                }
                $('.ptable_featureimg img').each(function(){
                        var srcImg = $(this).attr('src');
                        var newNum = getNum(srcImg).slice(1);
                        $(this).parent('.ptable_featureimg').addClass('img_' + newNum)
            });
        },
        initEvents : function()
        {
            $('#set-doctype').unbind('change');
            $('.add_promocode').unbind('click');
            $('#set-category').unbind('change');
            $('#set-doctype').bind('change',function(){
                PriceTable.onChangeDoctype();
            });
            $('.add_promocode').click(function(){
                PriceTable.setPromoCodes(this);
            });
            $('#set-category').change(function(){
                doUpdatePrices();
            });
            $('#set-interval').change(function(){
                doUpdatePrices();
            });
            if($('.currency_but a').length) {
                $('.currency_but a').bind('click', function() {
                    $('.currency_but a').removeClass('active');
                    $(this).addClass('active');
                });
            }
        },
        onChangeDoctype : function()
        {
            //hack for tests on stage (EOT-613)
            jQuery.active++;
            $price_area = $('#price-area');
            $.ajax({
                        url: "/admission_editing.reloadprice/",
                        type:'GET',
                        dataType: "text",
                        data: "ajaxPos=2&ajaxOrder=1&doctype=" +$('#set-doctype').val()+"&currency="+currency,
                    beforeSend: function(){
            $price_area.addClass('loading');
            $price_area.css({'text-align':'center'});
            $price_area.html('<span id="prices-loading"><img border="0" src="/res_v1560415138/img/icons/ajax-loader.gif" width="32" height="32" /></span>')
        },
            success: function(data){
                $price_area.removeClass('loading');
                $price_area.css({'text-align':'left'});
                $price_area.html(data);
                if(
                        PriceTable.promoCodes.promoruby instanceof Object && (PriceTable.promoCodes.promoruby.checked || PriceTable.promoCodes.promodiamond.checked)
                )
                {

                    $('#price_member_link').show();
                }
                else
                {
                    $('#price_member_link').hide();
                }
                setTimeout(
                        function(){
                            dt = parseInt($('#set-doctype').val());
                            var arr = new Array(125, 126, 152, 163, 174, 182, 217, 222);
                            var err_subj = 0;
                            if($('#set-doctype'))
                            {
                                for(var i=0;i<arr.length;i++)
                                {
                                    if(arr[i]==$('#set-doctype').val())
                                    {
                                        err_subj = 1;
                                    }
                                }
                                if(err_subj == 1)
                                {
                                    $('#subject_area').css('display','none');
                                }
                                else
                                {
                                    if ($('#subject_area').attr('tagName') == 'TR')
                                    {
                                        $('#subject_area').css('display','table-row');
                                    }
                                    else
                                    {
                                        $('#subject_area').css('display','block');
                                    }
                                }
                            }

                            PriceTable.pickOutPromo();
                            doUpdateFeatures();
                            doUpdateQuality();
                            doUpdatePrices();
                            PriceTable.reloadTooltip();
                            showMessageForDoctype(dt);
                            //hack for tests on stage (EOT-613)
                            jQuery.active--;

                            $('.currency_but a').removeClass('active');
                            $('.currency_but a').each(function() {
                                if($(this).text() == currency)
                                    $(this).addClass('active');
                            });

                            PriceTable.init();

                        },
                        0
                );
                PriceTable.initEvents();

                if (navigator.userAgent.indexOf('IE', 10) != -1){
                    setTimeout(function(){
                        $('#prices a.tooltip').each(function(){
                            if($(this).is('[rel]')){
                                var str = $(this).attr('rel');
                                var parent = $(this).parent('td');
                                   parent.addClass('exploer10');
                                   $('<span class="ieTooltip" />').appendTo(parent);
                                   $($(this).next('.ieTooltip')).html(str)
                            }else{
                                $(this).parent('td').removeClass('exploer10')
                            }
                        });


                        },0)
                };
            }


        });
    },
    reloadTooltip : function() {

    },
    pickOutPromo : function ()
    {
        for(i in PriceTable.promoCodes)
        {
            if ($('#add_promocode_' + PriceTable.promoCodes[i].code_id).length > 0 && PriceTable.promoCodes[i].checked)
            {
                $el = $('#add_promocode_' + PriceTable.promoCodes[i].code_id);
                if ($el[0])
                {
                    $el[0].checked = 'checked';
                }
            }
        }
    },
    setPromoCodes : function(elObj)
    {
        promo_code_id = $(elObj).attr('id').replace('add_promocode_','');
        for(i in PriceTable.promoCodes)
        {
            if (PriceTable.promoCodes[i].code_id == promo_code_id)
            {
                if ($(elObj)[0] && $(elObj)[0].checked)
                {
                    PriceTable.promoCodes[i].checked = true;
                }else
                {
                    PriceTable.promoCodes[i].checked = false;
                }
            }
        }
        doUpdatePrices();
    },
    getPromoDiscount : function(price, discountPpVal, discountPgVal, discountPgStaticVal)
    {
        priceWithPromoDiscount = 0;
        if (PriceTable.promoCodes)
        {
            for(ind in PriceTable.promoCodes)
            {
                if (
                        PriceTable.promoCodes[ind].checked &&
                        PriceTable.promoCodes[ind].value &&
                        PriceTable.promoCodes[ind].value/100 >= parseFloat(discountPpVal).toFixed(2) &&
                        PriceTable.promoCodes[ind].value/100 >= parseFloat(discountPgVal).toFixed(2)
                )
                {
                    switch(parseInt(PriceTable.promoCodes[ind].value_type))
                    {
                        case 0:
                            priceWithPromoDiscount = parseFloat(Math.round((100 - PriceTable.promoCodes[ind].value)/100 * price * 100)/100).toFixed(2);
                            break;
                        case 1:
                            priceWithPromoDiscount = parseFloat(Math.round((price - currencyRates[currency]*PriceTable.promoCodes[ind].value)*100)/100).toFixed(2);
                            break;
                    }
                    if (
                            discountPgStaticVal &&
                            ((price - priceWithPromoDiscount) <= discountPgStaticVal)
                    )
                    {
                        priceWithPromoDiscount = 0;
                    }
                }
            }
        }
        return priceWithPromoDiscount;
    },
    fieldsCheck : function()
    {
        var noErrors = {"pages_count":true, "papers_count":true};
        fields = ["pages_count","papers_count"];
        for(i = 0; i < fields.length; i++)
        {
            if($("#"+fields[i]).length && !filterInt($("#"+fields[i])))
            {
                noErrors[fields[i]] = false;
            }
        }
        if (noErrors["pages_count"] == false || noErrors["papers_count"] == false)
        {
            return false;
        } else {
            return true;
        }
    }
    }

    var $price_class_td_on_check_add_promocode = '';
    var $with_by_str = true;
    var $next_discount_count_text_type = 'pages';
    var $use_only_promo_discount = false;

    function doUpdatePrices()
    {
        if(!PriceTable.fieldsCheck())
        {
            return false;
        }

        $next_discount_count_text_type = 'pages';
        if (isProblemTypeDoctype())
        {
            $next_discount_count_text_type = 'problems';
        }
        discountPg = 1;
        discountPgStatic = 0;
        discountPp = 1;
        numpagesStr = numpapersStr = '';
        numpapers = 1;
        numpages = parseInt( $('#pages_count').attr( 'value' ) );
        if ( !numpages )
        {
            numpages = 1;
        }

        numpapers = parseInt( $('#papers_count').attr( 'value' ) );
        if (!numpapers)
        {
            numpapers = 1;
        }

        if ( !$use_only_promo_discount )
        {
            reloadDiscount(numpages, numpapers);
        }

        for(i in PriceTable.promoCodes)
        {
            if (
                    $('#add_promocode_' + PriceTable.promoCodes[i].code_id).length > 0 &&
                    $('#add_promocode_' + PriceTable.promoCodes[i].code_id).checked
            )
            {
                PriceTable.promoCodes[i].checked = true;
            }

            //!!! spike for prices table of Rush !!!
            if($('#add_promocode_' + PriceTable.promoCodes[i].code_id).attr('checked'))
            {
                if($('.add_promocode_clear'))
                {
                    $('.add_promocode_clear').removeClass("add_promocode_clear").addClass("add_promocode_new");
                    $("#discount_text").hide();
                    $("#discount_text_new").show();
                }
            }
        }

        var category_id = 0;
        if($("#set-category").length && $("#set-category").val() > 0)
        {
            category_id = $("#set-category").val();
        }

        var interval_id = 1;
        if($("#set-interval").length)
        {
            interval_id = parseInt($("#set-interval").val()) + 1;
        }

        var group_id = 0;

        if ( multiGroupPrices ) {
            for (key_group in multiGroupPrices.groups) {
                if ( multiGroupPrices.groups[key_group].from <= numpages && ( multiGroupPrices.groups[key_group].to >= numpages || multiGroupPrices.groups[key_group].to == 0 ) ) {
                    group_id = key_group;
                }
            }
        }

        for( i=0; i<uids.length; i++ )
        {
            $iter = 1;
            for( j=0; j<wlids.length; j++ )
            {
                $price_item_value = $("#val-"+uids[i]+"-"+wlids[j]);

                if( $price_class_td_on_check_add_promocode && $(".add_promocode") )
                {
                    if ( $(".add_promocode").attr('checked') )
                    {
                        $price_item_value.parent().addClass( $price_class_td_on_check_add_promocode );
                    }
                    else
                    {
                        $price_item_value.parent().removeClass( $price_class_td_on_check_add_promocode );
                    }
                }
                price_item = '&nbsp;';
                var price = 0;
                if(filterPagesNumber(numpages, dt, uids[i], wlids[j]) && ( !multiGroupPrices || ( multiGroupPrices && multiGroupPrices.prices[group_id][uids[i]] && multiGroupPrices.prices[group_id][uids[i]][wlids[j]] ) ) )
                {
                    price_without_discount = 0;
                    if (multiGroupPrices == undefined){
                        if (uids[i] && wlids[j] && plist[uids[i]] && plist[uids[i]][wlids[j]]){
                            price = plist[uids[i]][wlids[j]];
                        }
                    }
                    else if(multiGroupPrices && multiGroupPrices.prices)
                    {
                        price = multiGroupPrices.prices[group_id][uids[i]][wlids[j]];
                        price_first_group = [];
                        for (price_elem_key in multiGroupPrices.prices)
                        {
                            price_first_group = multiGroupPrices.prices[price_elem_key];
                            break;
                        }
                        if (price_first_group && price_first_group[uids[i]] && price_first_group[uids[i]][wlids[j]])
                        {
                            price_without_discount = price_first_group[uids[i]][wlids[j]];
                        }
                    }
                    if (!(dt in nonTechDoctypes) && (category_id in techCategories))
                    {
                        price += 10 / currencyRates['USD'];
                    }

                    for(n in intricateCategories)
                    {
                        if(!(dt in nonTechDoctypes) && intricateCategories[n] == category_id)
                        {
                            price += 3 / currencyRates['USD'];
                        }
                    }

                    if (statisticsCategory == category_id)
                    {
                        price *= 1.15;
                    }

                    if (category_id && PriceTable.categoriesPriceChange)
                    {
                        var c = parseInt(category_id);

                        if (PriceTable.categoriesPriceChange[c])
                        {
                            price += PriceTable.categoriesPriceChange[c];
                        }
                    }
                    /*---------------------------------------------*/

                    if (!price_without_discount)
                    {
                        price_without_discount = price;
                    }
                    var discount = discountPp < discountPg ? discountPp : discountPg;

                    var temp_price = Math.round( (parseFloat(price)*currencyRates[currency]).toFixed(2) * numpages * 100 * numpapers) / 100;
                    price_item = (interval_id * (temp_price - (temp_price * (1 - discount).toFixed(2)).toFixed(2))).toFixed(2);
                    var price_item_without_discount = (interval_id * (Math.round( (parseFloat(price_without_discount)*currencyRates[currency]).toFixed(2) * numpages * 100 * numpapers) / 100)).toFixed(2);
                    var js_link_id = '';
                    var order_link = 'order/';

                    if (use_js_link){
                        href = '#';
                        js_link_id = 'doctype-'+dt+'-urgency-'+uids[i]+'-wrlevel-'+wlids[j]+'-order_category-'+category_id+'-curr-'+currency + '-numpages-'+ numpages + '-numpapers-' + numpapers;
                    } else {
                        interval = interval_id - 1;
                        href = '/'+order_link+'?doctype='+dt+'&urgency='+uids[i]+'&wrlevel='+wlids[j]+'&order_category='+category_id+'&curr='+currency + numpagesStr + numpapersStr + '&o_interval=' + interval;
                    }

                    free_feature_desc = getFreeFeaturesDescr(dt, uids[i], wlids[j]);

                    free_feature_logo = free_feature_desc['desc'];
                    free_feature_title = '';
                    if (free_feature_desc['title']) {free_feature_title = 'rel="' + free_feature_desc['title'] + '"';}
                        link_class = 'pcolum_'+$iter;
                    if (free_feature[dt]) link_class += ' with_ff';
                    if (show_tooltip) link_class += ' tooltip';
                    if (use_js_link){ link_class += ' js-link'}

                    discountPricePromoCode = PriceTable.getPromoDiscount(price_item_without_discount, 1-discountPp, 1-discountPg, discountPgStatic);

                    if (discountPricePromoCode)
                    {
                        if (typeof(decoratePromoPrice) == 'undefined')
                        {
                            promo_html = '<span class="price_without_promo">'+currency_signes[currency] + price_item+'</span>';
                            for(promocode in PriceTable.promoCodes)
                            {
                                if (PriceTable.promoCodes[promocode].checked)
                                {
                                    href += '&promo='+promocode;
                                }
                            }
                            link_class += ' price_with_promo';
                            price_html = '<a  id="' + js_link_id + '" class="'+link_class+'" href="'+href+'" '+free_feature_title+' onmouseout="hideBuy(this);return false" onmouseover="showBuy(this);return false">'+ promo_html +'<span class="price_text">'+ free_feature_logo +'<span class="ptable_curr">' +currency_signes[currency]+'</span>' + cur_gap + discountPricePromoCode +($with_by_str?'<span class="price_tb_buy" style="display: none;">&nbsp;Buy</span>':'')+'</span></a>';
                        }
                        else
                        {
                            price_html = decoratePromoPrice(price_item, discountPricePromoCode, js_link_id, href, free_feature_title, free_feature_logo);
                        }
                        $price_item_value.html(price_html);
                    }else
                    {

                        var word_after_price = $('.price_tb_buy').html();
                        if(word_after_price == undefined)
                        {
                            word_after_price = '&nbsp;Buy';
                        }

                        $price_item_value.html( '<a id="' + js_link_id + '" class="'+link_class+'" href="'+href+'" '+free_feature_title+' onmouseout="hideBuy(this);return false" onmouseover="showBuy(this);return false"><span class="price_text">'+ free_feature_logo +'<span class="ptable_curr">' +currency_signes[currency]+'</span>' + cur_gap + price_item +($with_by_str?'<span class="price_tb_buy" style="display: none;">' + word_after_price + '</span>':'')+'</span></a>' );
                    }
                }
                else
                {
                    $price_item_value.html( price_item	);
                }
            }
        }

        PriceTable.reloadTooltip();
        if (use_js_link){
            PriceTable.enableJsLinks();
        }

        PriceTable.setImgPricesTable();

    }

    function reloadDiscount(numpages, numpapers)
    {
        var discount_text_html = '';
        is_adm = false;
        for ( di=0; di < adm_dt.length; di++ ) {
            if ( adm_dt[di] == dt ) {
                is_adm = true;
                break;
            }
        }

        if ( numpages >= 1 ) {
            numpagesStr = '&numpages=' + numpages;
        }

        if ( numpapers > 1 ) {
            numpapersStr = '&numpapers=' + numpapers;
        }
    }

    function doUpdateQuality()
    {
        if ($('#wr_level_desc').length > 0)
        {
            if ( ($('#set-doctype').attr('value') in show_wrlevel_description) || show_wrlevel_description_all || (!$('#set-doctype').length))
            {
                $('#wr_level_desc').show();
            } else
            {
                $('#wr_level_desc').hide();
            }
        }
    }

    function featuresLevelHide()
    {
        i = 0;max = 20;
        for(l = 0; l <= max; l++)
        {
            if(t = document.getElementById('features_level-'+l)) t.style.display = 'none';
        }
    }

    function doUpdateFeatures()
    {
        var elm = document.getElementById('set-doctype');
        if (elm && elm.length > 0)
        {
            if (!elm.value){
                var doctype_id = elm.options[elm.selectedIndex].value;
            } else {
                var doctype_id = elm.value;
            }
            featuresLevelHide();
            if (doctypeToFeatures)
            {
                for (key in doctypeToFeatures)
                {
                    if(t = document.getElementById('features_level-' + doctypeToFeatures[key]))
                    {
                        t.style.display = 'none';
                    }
                }
            }
            if (!(t = document.getElementById('features_level-'+doctypeToFeatures[doctype_id]))){
                t = document.getElementById('features_level-1');
            }
            if (t) {t.style.display = '';}
                    }
        }

        function showFeatures(doctype_id)
        {
            var t;
            featuresLevelHide();
            if (doctypeToFeatures)
            {
                for (key in doctypeToFeatures)
                {
                    if(t = document.getElementById('features_level-' + doctypeToFeatures[key]))
                    {
                        t.style.display = 'none';
                    }
                }
            }
            t = document.getElementById('features_level-'+doctypeToFeatures[doctype_id]);
            if (t)
            {
                t.style.display = '';
            }
        }

        function getFreeFeaturesDescr(doctype_id, urgency, wr_level)
        {
            free_feature_str = '';
            free_feature_title = '';
            return_array = {'desc':'', 'title':''};
            if (free_feature[doctype_id] && free_feature[doctype_id][urgency] && free_feature[doctype_id][urgency][wr_level])
            {
                // If count of free features > 1
                free_feature_data = free_feature[doctype_id][urgency][wr_level];
                if ( free_feature_data.toString().replace(/\,/,'') != free_feature_data.toString() )
                {
                    for(free_feature_key in free_feature_data)
                    {
                        free_feature_str = free_feature_data[free_feature_key];
                        free_feature_title += free_feature_data[free_feature_key] + free_feature_description[free_feature_data[free_feature_key]];
                    }
                }else{
                    free_feature_key = free_feature_data;
                    free_feature_str = free_feature_key;
                    free_feature_title = free_feature_description[free_feature_key];

                }
            }

            if(free_feature_discount[doctype_id] && free_feature_discount[doctype_id][urgency] && free_feature_discount[doctype_id][urgency][wr_level])
            {
                // If count of free features > 1
                free_feature_data = free_feature_discount[doctype_id][urgency][wr_level];

                if ( free_feature_data.toString().replace(/\,/,'') != free_feature_data.toString() ) {
                    for(free_feature_key in free_feature_data)
                    {
                        free_feature_str = free_feature_data[free_feature_key];
                        free_feature_title = free_feature_data[free_feature_key] + free_feature_description_discount[free_feature_data[free_feature_key]];
                    }
                }else{
                    free_feature_key = free_feature_data;
                    free_feature_str = free_feature_key;
                    free_feature_title = free_feature_key + free_feature_description_discount[free_feature_key];
                }
            }

            return_array['desc'] = '<span class="ptable_featureimg img_' + free_feature_str + '"></span>';
            return_array['title'] = free_feature_title;
            return return_array;
        }

        function filterPagesNumber(numpages, dt, urg, wrl)
        {
            if( numpages && limitList[dt] && limitList[dt][wrl] && limitList[dt][wrl][urg] && limitList[dt][wrl][urg] < numpages)
            {
                return false;
            }
            return true;
        }

        function filterInt(item)
        {
            var value = parseInt(item.val(), 10);
            if (isNaN(value) || value < 0)
            {
                value = '';
            }
            else if (value == 0)
            {
                value = 1;
            }
            $(item).val(value);

            checkPageNumberMax(item);

            if (item.val() != parseInt(item.val()) && item.val() < 1)
            {
                return false;
            }
            return true;
        }

        function checkPageNumberMax(item)
        {
            doctype = $("#set-doctype").val();

            doctypes400 = new Array();
            doctypes400[222] = 1;
            doctypes400[125] = 1;
            doctypes400[126] = 1;
            doctypes50 = new Array();
            doctypes50[51] = 1;
            doctypes50[182] = 1;
            doctypes50[260] = 1;
            doctypes50[262] = 1;
            doctypes50[261] = 1;
            if (item.attr('id') == 'papers_count' && typeof(number_of_applications_limit) !== 'undefined')
            {
                if(item.val() > number_of_applications_limit)
                {
                    item.val(number_of_applications_limit);
                }
            }
            else
            {
                if(doctypes400[doctype] )
                {
                    if(item.val() > 400)
                    {
                        item.val(400);
                    }
                }
                else if(doctypes50[doctype])
                {
                    if(item.val() > 50)
                    {
                        item.val(50);
                    }
                }
                else if( item.val() > 200)
                {
                    item.val(200);
                }
            }
        }

        function changeCurrency( curr_item, element_a )
        {
            currency = curr_item;
            doUpdatePrices();
            if ( element_a )
            {
                $('#sel_currency a').removeClass('active');
                $(element_a).addClass('active');
            }
        }

        function changeCurrencyBAE( curr_item, element_a )
        {
            currency = curr_item;
            doUpdatePrices();
            if ( element_a )
            {
                $('#sel_currency li').removeClass('active');
                $(element_a).addClass('active');
            }
        }

        function changeCurrencyRPH( curr_item, element_a )
        {
            currency = curr_item;
            doUpdatePrices();
            if ( element_a )
            {
                $('#sel_currency li a').removeClass('current');
                $(element_a).addClass('current');
            }
        }

        function changeCurrencyBQP( curr_item, element_a )
        {
            currency = curr_item;
            doUpdatePrices();
            if ( element_a )
            {
                $('.pr_cur').removeClass('pr_cur_current');
                $(element_a).parent().addClass('pr_cur_current');
            }
        }

        function isMultiChoiseDoctype(doctype_id)
        {
            is_multi = false;
            if (multi_dt && multi_dt.length)
            {
                for ( di=0; di < multi_dt.length; di++ )
                {
                    if ( multi_dt[di] == doctype_id )
                    {
                        is_multi = true;
                        break;
                    }
                }
            }
            return is_multi;
        }

        function isProblemTypeDoctype()
        {
            if ($.inArray($('#set-doctype').attr('value'),
                            ['234','139','124','234','235']) == -1)
            {
                return false;
            }
            return true;
        }

        function showMessageForDoctype(id_doctype)
        {
            var elem = $("#doctype_message-"+id_doctype)
            if (elem.length > 0)
            {
                elem.show();
            }
        }

        var currencyRates = {"AUD":1.44885,"CAD":1.33442,"EUR":0.88722,"GBP":0.78904,"USD":1};
        var currency_signes = {"GBP":"\u0026pound;","AUD":"A$\u0026nbsp;","EUR":"\u0026euro; ","CAD":"C$ ","USD":"$"};
        var adm_dt = [142,143,144,145,154];
        var multi_dt = [125,126,222];
        var free_feature = {"1":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"15":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"40":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"146":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"147":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"148":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"149":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"150":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"151":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"172":{"1":{"1":["232"]},"4":{"1":["231"],"2":["232"]},"6":{"2":["231"]},"11":{"2":["231"],"27":["231"]}},"0":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"13":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"14":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"37":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"38":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"39":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"80":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]},"11":{"28":["231"],"29":["231"]}},"83":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]},"11":{"28":["231"],"29":["231"]}},"84":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"85":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"234":{"5":{"2":["232"],"28":["231"],"29":["232"]},"7":{"2":["231"],"29":["231"]},"1":{"28":["232"]},"11":{"30":["231"],"29":["231"]}},"168":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"169":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"170":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]}},"171":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}},"173":{"1":{"1":["232"]},"5":{"1":["231"],"28":["232"]},"7":{"28":["231"]}},"242":{"1":{"1":["232"]},"5":{"1":["231"],"2":["232"]},"7":{"2":["231"]},"11":{"27":["231"],"2":["231"]}}};
        var free_feature_discount = [];
        var show_wrlevel_description = {"0":0,"13":13,"14":14,"39":39,"37":37,"38":38,"85":85,"1":1,"15":15,"172":172,"40":40,"146":146,"147":147,"148":148,"149":149,"150":150,"151":151,"159":159,"174":174,"152":152,"3":3,"163":163,"80":80,"83":83,"84":84,"234":234,"168":168,"169":169,"170":170,"171":171,"125":125,"126":126,"173":173,"51":51,"182":182,"218":218,"236":236};
        var show_wrlevel_description_all = false;

        var doctypeToFeatures = {"0":0,"13":1,"14":1,"15":1,"37":1,"38":1,"39":1,"40":1,"84":1,"85":1,"139":1,"146":1,"147":1,"148":1,"149":1,"150":1,"151":1,"51":1,"168":1,"169":1,"171":1};
        PriceTable.promoCodes = [];

        var intricateCategories= [];
        var statisticsCategory  = 139;

    var nonTechDoctypes = {125:125,126:126,152:152,163:163,174:174,182:182,217:217,222:222};
var techCategories = {67:67,65:65,71:71,70:70,72:72,73:73,75:75,77:77,162:162,157:157,158:158,159:159,163:163,125:125,126:126,160:160,161:161,136:136};

</script>

<script>
	$(".compare_p").click( function() {
		$("#wr_level_desc").toggle();
	})
</script>
</div>
          <section class="how_it_work">
<div class="header_part container">
<h4>See <strong>how it works</strong></h4>
<p>Get high-quality paper, completed by a team:</p>
<h5>Researcher + Writer + Proofreader</h5>
</div>
<div class="main_part hidden-xs">
<ul class="infographics">             <li class="infographics1"></li>             <li class="seporator"></li>             <li class="infographics2"></li>             <li class="seporator"></li>             <li class="infographics3"></li>             <li class="seporator"></li>             <li class="infographics4"></li>             <li class="seporator"></li>             <li class="infographics5"></li>         </ul>
    <ul class="infographics_subdcribe">
        <li>You place order with paper instructions</li>
        <li>Researcher prepares sources for the writer</li>
        <li>Writer from your subject completes your paper</li>
        <li>Paper is proofread and formatted</li>
        <li>You download the final paper</li>
    </ul>
    </div>
    <div class="container">
    <ul class="infographics_mobyle visible-xs">
        <li>You place order with paper instructions</li>
        <li>Researcher prepares sources for the writer</li>
        <li>Writer from your subject completes your paper</li>
        <li>Paper is proofread and formatted</li>
        <li>You download the final paper</li>
    </ul>
    </div>
    </section> 

     <section class="students_reviews pt_container">
        <div class="container">
        <div class="row">
        <div id="students_reviews_carousel" class="carousel slide col-sm-6" data-ride="carousel">
        <h4>What <strong>students say</strong> about Bestessays.com</h4>
        <div class="carousel-inner">
        <div class="item active">
        <div class="student_img hidden-sm"><img src="/images/img33.jpg" alt="" /></div>
        <blockquote>
        <h5>James W.</h5>
        <h6>- USA</h6>
        <p>Good essay writing service, I choose you instead of other website because of the nice service. I received a B+ for my essay (History, Yale University). Not an A because of the missing personal opinion. Great job!</p>
        <a href="/testimonials.php ">Read more reviews</a>     </blockquote></div>
        <div class="item">
        <div class="student_img hidden-sm"><img src="/images/img32.jpg" alt="" /></div>
        <blockquote>
        <h5>Paul S.</h5>
        <h6>- UK</h6>
        <p>I recently ordered a dissertation from your essay writing service and when I turned in my dissertation draft I was a little bit surprised that my teacher made so many corrections. I had to rewrite most of the first chapter. The dissertation writer made 2 revisions absolutely free and I am very satisfied with the final paper writing. I will use your custom essay writing service again in the future for essays and term papers.</p>
        <a href="/testimonials.php ">Read more reviews</a>     </blockquote></div>
        </div>
        <a class="left custom_control" href="#students_reviews_carousel" data-slide="prev">                     <span> </span>                 </a> <a class="right custom_control" href="#students_reviews_carousel" data-slide="next">                     <span> </span>                 </a></div>

        </div>
        </div>
    </section>   





    <section class="benefits_from_it visible-xs">
    <div class="container">
    <div class="row">
    <div class="col-md-6 col-sm-6">
    <div class="info_container">
    <h4>How you will benefit using academic paper writing service</h4>
    <ul class="numeric_list first_list">
        <li class="item_1">Save your time</li>
        <li class="item_2">Improve your grades</li>
        <li class="item_3">Save your subject</li>
        <li class="item_4">Get help with the research</li>
    </ul>
    <a class="button benefit_button" href="/order">Get a Quote</a></div>
    </div>
    <div class="col-md-6  col-sm-6">
    <div class="info_container">
    <h4>Why choose Bestessays.com</h4>
    <ul class="numeric_list second_list">
        <li class="item_1">Professional <strong>writers with Master and PhD</strong> degrees</li>
        <li class="item_2"><strong>15% OFF any paper</strong> for new customers; flexible discounts for returning customer</li>
        <li class="item_3"><strong>FREE</strong> amendments, formatting, title and reference page</li>
        <li class="item_4"><strong>3-hr service</strong> is available</li>
        <li class="item_5"><strong>Direct contact</strong> with your writer</li>
    </ul>
    </div>
    </div>
    </div>
    </div>
    </section>    
          <div class="rs_main_part container"><a class="button_order_now" href="/order">Order now</a></div>    
  <section class="seo_text">
    <div class="container">
    <div class="row">
    <div class="col-md-6">
<p>
    Ready to make an impression and get started seizing your future? Well, grab on with both hands! Send your draft admission essay, personal statement, or scholarship essay to our editors. Our editors will take on the task of ensuring your essay uses correct grammar, punctuation and style; so that you may concentrate on the central question and ensure you express what you have to say without worrying too much about how you expressed it. With a team of professional editors at your disposal, you can't help but to turn out a well polished and sincere statement truly reflective of you and your accomplishments.
</p>
</div>
    <div class="col-md-6">
<p>What you will get
</p>
    <ul>
        <li>proofread, polished Admission Essay/Scholarship Essay/Personal Statement edited by professional English writer;</li>
        <li>formatting of you admission paper;</li>
        <li>free amendments if required;</li>
        <li>paper format: 275 words per page, Times New Roman font, size 12, double-spaced text, 1 inch margin;</li>
        <li>on time delivery, direct download of the order;</li>
        <li>guaranteed privacy.</li>
    </ul>
</div>
    </div>
    </section>          <style type="text/css">
.mainBanner {
    max-width: 700px;
    margin: 0px auto;
    padding: 0px 20px;
}
#dynamicBanner {
padding-top: 30% !important;
}
</style>
 
<section class="benefits_from_it hidden-xs">
<div class="container">
<div class="row">
<div class="col-md-6 col-sm-6">
<div class="info_container">
<h4>How you will benefit using academic paper writing service</h4>
<ul class="numeric_list first_list">
    <li class="item_1">Save your time</li>
    <li class="item_3">Save your subject</li>
    <li class="item_4">Get help with the research</li>
</ul>
<a href="/order" class="button benefit_button">Order Now</a></div>
</div>
<div class="col-md-6  col-sm-6">
<div class="info_container">
<h4>Why choose Bestessays.com</h4>
<ul class="numeric_list second_list">
    <li class="item_1">Professional <strong>writers with Master and PhD</strong> degrees</li>
    <li class="item_2"><strong>15% OFF any paper</strong> for new customers; flexible discounts for returning customer</li>
    <li class="item_3"><strong>FREE</strong> amendments, formatting, title and reference page</li>
    <li class="item_4"><strong>3-hr service</strong> is available</li>
</ul>
</div>
</div>
</div>
</div>
</section>








  <section class="place_for_baner">
<div class="mainBanner"><a href="/order" id="dynamicBanner" class="firstTime">               </a></div>
</section>


    
          <style type="text/css">
    .pricetable_terms .button {
        width:auto;
        display:inline-block;
        padding-left: 20px;
        padding-right: 20px;
    }
</style> 
<!--
<section class="pricetable_terms">
    <div class="container">
        <div class="row">
            <div class=" col-md-4 col-sm-6 col-xs-12">
                <div class="terms_container">
                    <h5>FREE features in every order</h5>
                    <div class="left_side">
                        <h2>FREE</h2>
                        <h4>Total savings: <span>$65</span></h4>
                        <h6>(*Provided upon request)</h6>
                    </div>
                    <div class="right_side">
                        <p>Outline <span>$5</span></p>
                        <p>Amendments*<span>$30</span></p>
                        <p>Title Page<span>$5</span></p>
                        <p>Bibliography<span>$15</span></p>
                        <p>Formatting<span>$10</span></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6">
                <div class="terms_container">
                    <h5>Format</h5>
                    <ul class="purple_label">
                        <li>275/page (double spaced)<br />
                            550/page (single spaced)</li>
                        <li>1 inch margin</li>
                        <li>12 pt, Times New Roman</li>
                    </ul>
                </div>
            </div>
        
            <div class="col-md-4 col-sm-12 col-xs-6">
                <div class="terms_container terms_our_discounts">
                    <h5>Our Discounts</h5>
                    <div>
                        <div>5% off</div>
                        <p>15-50 pages</p>
                    </div>
                    <div>
                        <div>10% off</div>
                        <p>51-100 pages</p>
                    </div>
                    <div>
                        <div>15% off</div>
                        <p>101+ pages</p>
                    </div>
                </div>
            </div>
           
            <div class="clearfix"></div>
            <div class="text-center"><a class="button firstTime" id="dynamicLink" href="/order">Request paper now</a></div>
        </div>
    </div>
</section>
-->    
    </div></div>          <footer>
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-lg-8 col-sm-12 col-xs-5">
                <div class="row bottom_links">
                    <div class="col-md-4 col-sm-4">
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="/prices.php">Prices</a></li>
                            <li><a href="/order">Order custom essay</a></li>
                            <li><a href="/samples.php">Sample Essays</a></li>
                            <li><a href="/custom_term_paper.php">Custom term paper</a></li>
                            <li><a href="/affiliate.php/">Affiliate program</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <ul>
                            <li><a href="/doc_essay.php">Custom essay</a></li>
                            <li><a href="/custom_research_paper.php">Research paper</a></li>
                            <li><a href="/write-my-essay.php">Write my essay</a></li>
                            <li><a href="/essay_writers.php">Essay writers</a></li>
                            <li><a href="/custom_writing.php">Writing Process</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <ul>
                            <li><a href="/customersupport.php">Contact us</a></li>
                            <li><a href="/glossary.php">Glossary</a></li>
                            <li><a href="/disclaimer.php">Terms and conditions</a></li>
                            <li><a href="/privacy_policy.php">Privacy policy</a></li>
                            <li><a href="/sitemap.php">Sitemap</a></li>
                            <li><a href="/custompaperfaq.php ">FAQ</a></li>
                        </ul>
                    </div>
                </div>

                <div class="row hidden-xs footer_contacts">
                    <div class="col-md-3 col-sm-3">
                       <h6>US Sales Toll-Free</h6>
                       <p>+1-888-533-4942</p>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <h6>US Support Toll-Free</h6>
                        <p>+1-888-357-6549</p>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <h6>UK Toll Free</h6>
                        <p>+44-808-189-1011</p>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <h6>AU Toll Free</h6>
                        <p>+61-1-800-704995</p>
                    </div>
                </div>
            </div>
            <div class=" visible-xs col-xs-7 footer_contacts">
                <div class="col-md-3 col-sm-3">
                    <h6>US Sales Toll-Free</h6>
                    <p>1-888-533-4942</p>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h6>US Support Toll-Free</h6>
                    <p>1-888-357-6549</p>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h6>UK Toll Free</h6>
                    <p>+44-808-189-1011</p>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h6>AU Toll Free</h6>
                    <p>+61-1-800-704995</p>
                </div>
            </div>
            <div class="payment_wrapper hidden-sm ">
                <div class="row payment_container">
                    <div class="left_part">
                        <a class="payment_1" href="javascript:void(0);"></a>
                        <a class="payment_2" href="javascript:void(0);"></a>
                        <a class="payment_3" href="javascript:void(0);"></a>
                        <a class="payment_4" href="javascript:void(0);"></a>
                        <a class="payment_5" href="javascript:void(0);"></a>
                    </div>
                    <div class="right_part">
                        <p>All payments are securely processed by</p>
                        <a href="https://www.securitymetrics.com/site_certificate.adp?s=bestessays%2ecom&i=1230177"></a>
                    </div>
                </div>
                
            </div>

        </div>
        <div class="row payment_container tablet_variant visible-sm">
            <div class="left_part">
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <!--<a href="javascript:void(0);"></a>-->
            </div>
            <div class="right_part">
                <a href="https://www.securitymetrics.com/site_certificate.adp?s=bestessays%2ecom&i=1230177">
                </a>
                <p>All payments are securely processed</p>
            </div>
        </div>
        <p class="hidden-xs"> 1997-<script>d = new Date();document.write(d.getFullYear());</script> "BestEssays.com"</p>
    </div>
</footer>
<section class="disclamer">
    <div class="disclamer_text"></div>
</section>


<script>
var banner = (function () {
    function removeClass(el,classNm) {
        var currClass = el.getAttribute('class');
        var classResult = currClass.replace(classNm,'');
        el.setAttribute('class',classResult);
    };
    function addClass(el,classNm) {
        el.setAttribute('class',el.className+' '+classNm);
    };
    function hasClass(el,classNm) {
        var currClass = el.getAttribute('class') || '';
        if (currClass.indexOf(classNm) != -1) {
            return true;
        } else {
            return false;
        }
    };
    function cookieExists(cookieName) {
        return (document.cookie.indexOf(cookieName) != -1) ? true : false;
    };
    function init(bannerUniqueID,buttonUniqueID,cookie) {
        var $banner = $(bannerUniqueID),
    $button = $(buttonUniqueID),
    $textAfter = $(buttonUniqueID + ' + h6');
if (cookieExists(cookie) === true) {
    $button.add($banner).removeClass('firstTime');
    $banner.attr({
        href: '/order/',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'discount_banner_old_customers_new_design', '']);"
    });
    $button.attr({
        href: '/order/',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'top_button_old_customers_new_design', '']);"
    });
    $button.html('REQUEST PAPER NOW');
    $textAfter.hide();
} else {
    $banner.addClass('firstTime');
    $banner.attr({
        href: '/order/?promo=begin15',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'banner_15off_new_design', '']);"
    });
    $button.addClass('firstTime');
    $button.attr({
        href: '/order/?promo=begin15',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'top_button_15off_new_design', '']);"
    });
    $button.html('Try service with <strong>15% discount*</strong>');
    $textAfter.show();
}
    };
    return {
        check : init
    }
}());
</script> <script>banner.check('#dynamicBanner','#dynamicLink','_hpo');	</script>

<div class="wrapper-email-popup">
<div class="shadow-wrapp"></div>
<div class="block-email-popup">
<div class="close-email-popup"><img src="/images/cls-but.jpg" alt="X"></div>
<div class="wrapper-form">
<form class="email-form" action="#" method="POST">
<div class="wrap-input-field">
<label for="name-user-email">Your name:</label>
<input id="name-user-email" type="text"><div class="error-message">Enter your name</div>
</div>
<div class="wrap-input-field">
<label for="email-user">Email:</label>
<input id="email-user" type="text"><div class="error-message">Enter valid email address</div>
</div>
<div class="wrap-input-field"><input id="send-email" value="Apply" type="button"></div>
</form>
</div>
<div class="thank-block">
<div class="title-thank">Thank you.</div><p>Our representatives will contact<br>you within 24 hours.</p>
</div>
</div>
</div>
    
          <!-- BoldChat Conversion Tracking HTML v5.10 (Website=www.bestessays.com,ConversionCode=test conversion code) -->
<script type="text/javascript">
    window._bcvma = window._bcvma || [];
    _bcvma.push(["setAccountID", "161178856198874968"]);
    _bcvma.push(["addConversion", {
      ConversionAmount: dataLayer[0].transactionTotal,
      ConversionRef: dataLayer[0].transactionId,
      ConversionInfo: "",
      WebsiteID: "1985431959216183439",
      ConversionCodeID: "3070130503748985491"
    }]);
  var bcLoad = function(){
    if(window.bcLoaded) return; window.bcLoaded = true;
    var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
    vms.src = ('https:'==document.location.protocol?'https://':'https://') + "vmss.boldchat.com/aid/161178856198874968/bc.vms4/vms.js";
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
  };
  if(window.pageViewer && pageViewer.load) pageViewer.load();
  else bcLoad();</script>
<noscript>
<a href="https://www.boldchat.com" title="Live Chat Software" target="_blank"><img alt="Live Chat Software" src="https://vms.boldchat.com/aid/161178856198874968/bc.vci?wdid=1985431959216183439&ccid=3070130503748985491&ca=&cr=&ci=" border="0" width="1" height="1" /></a>
</noscript>
<!-- /BoldChat Conversion Tracking HTML v5.10 -->
    
          <style>
.bcFloat{
bottom:0!important;
right:0!important;
top:auto!important;
left:auto!important;
position:fixed!important;
}
</style>
<!-- BoldChat Visitor Monitor HTML v5.00 (Website=www.bestessays.com,ChatButton=Dev button float,ChatInvitation=Prices ) -->
<script type="text/javascript">
  window._bcvma = window._bcvma || [];
  _bcvma.push(["setAccountID", "161178856198874968"]);
  _bcvma.push(["setParameter", "WebsiteID", "1985431959216183439"]);
  _bcvma.push(["setParameter", "VisitInfo", dataLayer[0].userId]);
  _bcvma.push(["setParameter", "InvitationID", "29777179604711897"]);
  _bcvma.push(["addFloat", {type: "chat", id: "3771936857143385943"}]);
  _bcvma.push(["pageViewed"]);
  var bcLoad = function(){
    if(window.bcLoaded) return; window.bcLoaded = true;
    var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
    vms.src = ('https:'==document.location.protocol?'https://':'https://') + "vmss.boldchat.com/aid/161178856198874968/bc.vms4/vms.js";
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
  };
  if(window.pageViewer && pageViewer.load) pageViewer.load();
  else if(document.readyState=="complete") bcLoad();
  else if(window.addEventListener) window.addEventListener('load', bcLoad, false);
  else window.attachEvent('onload', bcLoad);
</script>
<noscript>
<a href="https://www.boldchat.com" title="Live Chat Software" target="_blank"><img alt="Live Chat Software" src="https://vms.boldchat.com/aid/161178856198874968/bc.vmi?wdid=1985431959216183439&vi=userID&curl=" border="0" width="1" height="1" /></a>
</noscript>
<!-- /BoldChat Visitor Monitor HTML v5.00 -->
    
          <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MTC9MMT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    
  <script src="//rum-static.pingdom.net/pa-59f072b5f3f14ae82c7b23c6.js" async></script><script src="/build/adaptive.263784e454a851df9e21.js" async></script>
<style>
.cookies {
  position: fixed;
  bottom: 0;
  z-index: 999999998;
  background: rgba(255, 255, 255, 0.85);
  width: 100%;
  color: #fff;
  text-align: center;
  display: none;
  left: 0;
  border-top: 1px solid #ddd;
  padding: 0 220px 0 20px;
  box-sizing: border-box;
}
#accept_cookie_window .cookies_text {
    margin: 10px auto;
    position: relative;
    color: #000;
    text-align: center;
    font-size: 12px;
    font-family: Arial, sans-serif;
    padding: 0;
    line-height: 1.3;
    box-sizing: border-box;
}
.cookies__close {
  cursor: pointer;
  display: inline-block;
  background: #C4D7ED;
  padding: 2px 4px;
  border-radius: 5px;
  margin-left: 10px;
}
.cookies__close:hover {
  background: #9bc3f1;
  color: #353535;
}
.bcFloat {
  z-index: 999999999 !important;
}
.cookies br {
  display: none;
}
@media all and (max-width: 1480px) {
  .cookies {
    padding: 0 0 0 20px;
  }
  #accept_cookie_window .cookies_text {
    padding-right: 200px;
  }
  .cookies .cookies-br__second {
    display: inline;
  }
}
@media all and (max-width: 1100px) {
  .cookies .cookies-br__first {
    display: inline;
  }
}
@media only screen and (max-device-width: 736px) {
  .cookies {
    padding: 0 120px 0 20px;
  }
  #accept_cookie_window .cookies_text {
    font-size: 11px;
    padding-right: 0;
  }
  .cookies .cookies-br__first,
  .cookies .cookies-br__second {
    display: none;
  }
}
</style>
<div id="accept_cookie_window" class="cookies">
            <p class="cookies_text">We use cookies to make sure you have the best experience on our website.<br class="cookies-br__first" />
                You can control what cookies are set on your device in your "cookies settings".<br class="cookies-br__second" />
                If you continue to use this site, you consent to our use of cookies.<span class="cookies__close" id="accept_cookie_window_close" onclick="acceptCookie()">Close</span></p>
                <script>
                document.addEventListener("DOMContentLoaded", function(event) {
                    setTimeout(function() {
                        if(window.jQuery) {
                            $(".cookies").fadeIn(300);
                        } else {
                            var element = document.getElementById("accept_cookie_window");
                            element.style.display = "block";
                        }
                    }, 3000);

                    if(window.jQuery) {
                        $(".cookies__close").click(function(){
                            $(".cookies").fadeOut(300);
                        });
                    } else {
                        var element = document.getElementById("accept_cookie_window_close");
                        element.onclick = function() {
                            var element = document.getElementById("accept_cookie_window");
                            element.style.display = "none";
                            acceptCookie();
                        };
                    }
                });
                    function acceptCookie() {
                        var date = new Date(new Date().getTime() + 7776000 * 1000);
                        document.cookie = "accept_cookie=true; path=/; expires=" + date.toUTCString();
                    }
                </script>
        </div></body></html>