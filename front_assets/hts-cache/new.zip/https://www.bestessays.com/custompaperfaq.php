<!doctype html><html lang="en" xmlns:fb="https://www.facebook.com/2008/fbml"><head><script src="/res_v1560415138/js/js-error-log.js" type="text/javascript"></script><link rel="manifest" href="/../manifest.json"><meta name="msapplication-config" content="/../browserconfig.xml">     <script>
        dataLayer = [{
            'userId': '0'
        }];
    </script>
              
          <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MTC9MMT');</script>
<!-- End Google Tag Manager -->    
          <!--  OneSignal  -->
    <script src="//cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
    <script>
        var OneSignal = OneSignal || [];
        OneSignal.push(["init", {
            appId: "bb0fbb64-603b-44e3-9cc7-50321eb8135c",
            autoRegister: true,
            notifyButton: {
                enable: false /* Set to false to hide */
            },
            safari_web_id: 'web.onesignal.auto.1b5e3a9a-fd8d-4cbc-b150-cc0a98b0f0fe'
        }]);
    </script>
<!--  End OneSignal  -->    
          <meta name="google-site-verification" content="TMIE4J4vH0OJ1VA45i4xMaGBHtJBOk_gBdCT_vxrl_s" />
    
   <title>FAQ about Our Writing Service | BestEssays.com</title>  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>  <meta name="description" content="You have questions about our essay writing service? Wanna know how it works? Read the answers to FAQs at our website. We give you the info you need."/>   <meta charset="utf-8"><meta name="viewport" content="width=device-width"><style> @font-face{font-family:Open Sans;font-style:normal;font-weight:300;src:local("Open Sans Light"),local("OpenSans-Light"),url(/styles/fonts/open-sans-v15-latin-300.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-300.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:400;src:local("Open Sans Regular"),local("OpenSans-Regular"),url(/styles/fonts/open-sans-v15-latin-regular.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-regular.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:600;src:local("Open Sans SemiBold"),local("OpenSans-SemiBold"),url(/styles/fonts/open-sans-v15-latin-600.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-600.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:700;src:local("Open Sans Bold"),local("OpenSans-Bold"),url(/styles/fonts/open-sans-v15-latin-700.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-700.woff) format("woff")}@font-face{font-family:Open Sans;font-style:normal;font-weight:800;src:local("Open Sans ExtraBold"),local("OpenSans-ExtraBold"),url(/styles/fonts/open-sans-v15-latin-800.woff2) format("woff2"),url(/styles/fonts/open-sans-v15-latin-800.woff) format("woff")}.logo-block .flex-wrapper{-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding:20px}.logo-block .flex-wrapper,.logo-block__support{display:-webkit-box;display:-ms-flexbox;display:flex}.logo-block__support{-webkit-box-align:center;-ms-flex-align:center;align-items:center}.logo-block__support a{display:inline-block;margin-left:10px;padding:5px 30px;border:1px solid #9f88da;text-align:center;color:#fff;border-radius:15px}.fb-messager__link{display:-webkit-box!important;display:-ms-flexbox!important;display:flex!important;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-ms-flex-pack:distribute;justify-content:space-around}.fb-messager__text{margin-bottom:0;color:#fff!important}.fb-messager{width:173px}.logo-block__support a span:before{content:"";display:inline-block;margin-right:2px;vertical-align:middle;margin-top:0;width:7px;height:7px;background:#3dd256;border-radius:50%;margin-left:10px}.logo-block__support a:last-child:before{content:"";display:inline-block;margin-right:10px;background-image:url(/build/37a753b37bab035f53d9561de79c847e.png);background-position:-486px -164px;width:12px;height:17px;vertical-align:middle;margin-top:-5px}.fb-messager__link:before{display:none!important}.logo-block__support a:hover{text-decoration:none;background:#896ebb;-webkit-transition:.4s;transition:.4s}@media (max-width:1200px){.logo-block .flex-wrapper{-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.fb-messager__link{padding:5px 25px!important}}@media (max-width:1024px){.logo-block__logo{display:none}.logo-block .flex-wrapper{-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}}@media (max-width:767px){.logo-block{display:block}.logo-block__support a{padding:5px 20px!important}.logo-block .flex-wrapper{padding:35px 20px 20px}}@media (max-width:670px){.logo-block .flex-wrapper{-ms-flex-pack:distribute;justify-content:space-around}.fb-messager__text{font-size:0}.logo-block__support a span{display:none}.fb-messager{width:62px}.logo-block__support{width:100%;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.logo-block__support a{margin-left:0;padding-left:5px!important;padding-right:5px!important}.fb-messager{-webkit-box-ordinal-group:4;-ms-flex-order:3;order:3}.logo-block__support a:nth-of-type(2){-webkit-box-ordinal-group:2;-ms-flex-order:1;order:1}.logo-block__support a:first-of-type{-webkit-box-ordinal-group:3;-ms-flex-order:2;order:2}.fb-messager__link{padding:5px 25px!important;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.logo-block,.logo-block .flex-wrapper{padding-left:0!important;padding-right:0!important}}.btn-danger,.btn-default,.btn-info,.btn-primary,.btn-success,.btn-warning{text-shadow:0 -1px 0 rgba(0,0,0,.2);-webkit-box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 1px rgba(0,0,0,.075)}.btn-danger.active,.btn-danger:active,.btn-default.active,.btn-default:active,.btn-info.active,.btn-info:active,.btn-primary.active,.btn-primary:active,.btn-success.active,.btn-success:active,.btn-warning.active,.btn-warning:active{-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);box-shadow:inset 0 3px 5px rgba(0,0,0,.125)}.btn.active,.btn:active{background-image:none}.btn-default{text-shadow:0 1px 0 #fff;background-image:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#e0e0e0));background-image:-webkit-linear-gradient(top,#fff,#e0e0e0);background-image:linear-gradient(180deg,#fff 0,#e0e0e0);background-repeat:repeat-x;border-color:#ccc}.btn-default:focus,.btn-default:hover{background-color:#e0e0e0;background-position:0 -15px}.btn-default.active,.btn-default:active{background-color:#e0e0e0;border-color:#dbdbdb}.btn-primary{background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#2d6ca2));background-image:-webkit-linear-gradient(top,#428bca,#2d6ca2);background-image:linear-gradient(180deg,#428bca 0,#2d6ca2);background-repeat:repeat-x;border-color:#2b669a}.btn-primary:focus,.btn-primary:hover{background-color:#2d6ca2;background-position:0 -15px}.btn-primary.active,.btn-primary:active{background-color:#2d6ca2;border-color:#2b669a}.btn-success{background-image:-webkit-gradient(linear,left top,left bottom,from(#5cb85c),to(#419641));background-image:-webkit-linear-gradient(top,#5cb85c,#419641);background-image:linear-gradient(180deg,#5cb85c 0,#419641);background-repeat:repeat-x;border-color:#3e8f3e}.btn-success:focus,.btn-success:hover{background-color:#419641;background-position:0 -15px}.btn-success.active,.btn-success:active{background-color:#419641;border-color:#3e8f3e}.btn-info{background-image:-webkit-gradient(linear,left top,left bottom,from(#5bc0de),to(#2aabd2));background-image:-webkit-linear-gradient(top,#5bc0de,#2aabd2);background-image:linear-gradient(180deg,#5bc0de 0,#2aabd2);background-repeat:repeat-x;border-color:#28a4c9}.btn-info:focus,.btn-info:hover{background-color:#2aabd2;background-position:0 -15px}.btn-info.active,.btn-info:active{background-color:#2aabd2;border-color:#28a4c9}.btn-warning{background-image:-webkit-gradient(linear,left top,left bottom,from(#f0ad4e),to(#eb9316));background-image:-webkit-linear-gradient(top,#f0ad4e,#eb9316);background-image:linear-gradient(180deg,#f0ad4e 0,#eb9316);background-repeat:repeat-x;border-color:#e38d13}.btn-warning:focus,.btn-warning:hover{background-color:#eb9316;background-position:0 -15px}.btn-warning.active,.btn-warning:active{background-color:#eb9316;border-color:#e38d13}.btn-danger{background-image:-webkit-linear-gradient(top,#d9534f,#c12e2a);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9534f),to(#c12e2a));background-image:linear-gradient(180deg,#d9534f 0,#c12e2a);background-repeat:repeat-x;border-color:#b92c28}.btn-danger:focus,.btn-danger:hover{background-color:#c12e2a;background-position:0 -15px}.btn-danger.active,.btn-danger:active{background-color:#c12e2a;border-color:#b92c28}.img-thumbnail,.thumbnail{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.075);box-shadow:0 1px 2px rgba(0,0,0,.075)}.dropdown-menu>li>a:focus,.dropdown-menu>li>a:hover{background-color:#e8e8e8;background-image:-webkit-linear-gradient(top,#f5f5f5,#e8e8e8);background-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#e8e8e8));background-image:linear-gradient(180deg,#f5f5f5 0,#e8e8e8);background-repeat:repeat-x}.dropdown-menu>.active>a,.dropdown-menu>.active>a:focus,.dropdown-menu>.active>a:hover{background-color:#357ebd;background-image:-webkit-linear-gradient(top,#428bca,#357ebd);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#357ebd));background-image:linear-gradient(180deg,#428bca 0,#357ebd);background-repeat:repeat-x}.navbar-default{background-image:-webkit-linear-gradient(top,#fff,#f8f8f8);background-image:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#f8f8f8));background-image:linear-gradient(180deg,#fff 0,#f8f8f8);background-repeat:repeat-x;border-radius:4px;-webkit-box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 5px rgba(0,0,0,.075);box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 5px rgba(0,0,0,.075)}.navbar-default .navbar-nav>.active>a{background-image:-webkit-linear-gradient(top,#ebebeb,#f3f3f3);background-image:-webkit-gradient(linear,left top,left bottom,from(#ebebeb),to(#f3f3f3));background-image:linear-gradient(180deg,#ebebeb 0,#f3f3f3);background-repeat:repeat-x;-webkit-box-shadow:inset 0 3px 9px rgba(0,0,0,.075);box-shadow:inset 0 3px 9px rgba(0,0,0,.075)}.navbar-brand,.navbar-nav>li>a{text-shadow:0 1px 0 hsla(0,0%,100%,.25)}.navbar-inverse{background-image:-webkit-linear-gradient(top,#3c3c3c,#222);background-image:-webkit-gradient(linear,left top,left bottom,from(#3c3c3c),to(#222));background-image:linear-gradient(180deg,#3c3c3c 0,#222);background-repeat:repeat-x}.navbar-inverse .navbar-nav>.active>a{background-image:-webkit-linear-gradient(top,#222,#282828);background-image:-webkit-gradient(linear,left top,left bottom,from(#222),to(#282828));background-image:linear-gradient(180deg,#222 0,#282828);background-repeat:repeat-x;-webkit-box-shadow:inset 0 3px 9px rgba(0,0,0,.25);box-shadow:inset 0 3px 9px rgba(0,0,0,.25)}.navbar-inverse .navbar-brand,.navbar-inverse .navbar-nav>li>a{text-shadow:0 -1px 0 rgba(0,0,0,.25)}.navbar-fixed-bottom,.navbar-fixed-top,.navbar-static-top{border-radius:0}.alert{text-shadow:0 1px 0 hsla(0,0%,100%,.2);-webkit-box-shadow:inset 0 1px 0 hsla(0,0%,100%,.25),0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 hsla(0,0%,100%,.25),0 1px 2px rgba(0,0,0,.05)}.alert-success{background-image:-webkit-linear-gradient(top,#dff0d8,#c8e5bc);background-image:-webkit-gradient(linear,left top,left bottom,from(#dff0d8),to(#c8e5bc));background-image:linear-gradient(180deg,#dff0d8 0,#c8e5bc);background-repeat:repeat-x;border-color:#b2dba1}.alert-info{background-image:-webkit-linear-gradient(top,#d9edf7,#b9def0);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9edf7),to(#b9def0));background-image:linear-gradient(180deg,#d9edf7 0,#b9def0);background-repeat:repeat-x;border-color:#9acfea}.alert-warning{background-image:-webkit-linear-gradient(top,#fcf8e3,#f8efc0);background-image:-webkit-gradient(linear,left top,left bottom,from(#fcf8e3),to(#f8efc0));background-image:linear-gradient(180deg,#fcf8e3 0,#f8efc0);background-repeat:repeat-x;border-color:#f5e79e}.alert-danger{background-image:-webkit-linear-gradient(top,#f2dede,#e7c3c3);background-image:-webkit-gradient(linear,left top,left bottom,from(#f2dede),to(#e7c3c3));background-image:linear-gradient(180deg,#f2dede 0,#e7c3c3);border-color:#dca7a7}.alert-danger,.progress{background-repeat:repeat-x}.progress{background-image:-webkit-linear-gradient(top,#ebebeb,#f5f5f5);background-image:-webkit-gradient(linear,left top,left bottom,from(#ebebeb),to(#f5f5f5));background-image:linear-gradient(180deg,#ebebeb 0,#f5f5f5)}.progress-bar{background-image:-webkit-linear-gradient(top,#428bca,#3071a9);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#3071a9));background-image:linear-gradient(180deg,#428bca 0,#3071a9);background-repeat:repeat-x}.progress-bar-success{background-image:-webkit-linear-gradient(top,#5cb85c,#449d44);background-image:-webkit-gradient(linear,left top,left bottom,from(#5cb85c),to(#449d44));background-image:linear-gradient(180deg,#5cb85c 0,#449d44);background-repeat:repeat-x}.progress-bar-info{background-image:-webkit-linear-gradient(top,#5bc0de,#31b0d5);background-image:-webkit-gradient(linear,left top,left bottom,from(#5bc0de),to(#31b0d5));background-image:linear-gradient(180deg,#5bc0de 0,#31b0d5);background-repeat:repeat-x}.progress-bar-warning{background-image:-webkit-linear-gradient(top,#f0ad4e,#ec971f);background-image:-webkit-gradient(linear,left top,left bottom,from(#f0ad4e),to(#ec971f));background-image:linear-gradient(180deg,#f0ad4e 0,#ec971f);background-repeat:repeat-x}.progress-bar-danger{background-image:-webkit-linear-gradient(top,#d9534f,#c9302c);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9534f),to(#c9302c));background-image:linear-gradient(180deg,#d9534f 0,#c9302c);background-repeat:repeat-x}.list-group{border-radius:4px;-webkit-box-shadow:0 1px 2px rgba(0,0,0,.075);box-shadow:0 1px 2px rgba(0,0,0,.075)}.list-group-item.active,.list-group-item.active:focus,.list-group-item.active:hover{text-shadow:0 -1px 0 #3071a9;background-image:-webkit-linear-gradient(top,#428bca,#3278b3);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#3278b3));background-image:linear-gradient(180deg,#428bca 0,#3278b3);background-repeat:repeat-x;border-color:#3278b3}.panel{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.05);box-shadow:0 1px 2px rgba(0,0,0,.05)}.panel-default>.panel-heading{background-image:-webkit-linear-gradient(top,#f5f5f5,#e8e8e8);background-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#e8e8e8));background-image:linear-gradient(180deg,#f5f5f5 0,#e8e8e8);-webkit-filter:progid:DXImageTransfzorm.Microsoft.gradient(startColorstr="#fff5f5f5",endColorstr="#ffe8e8e8",GradientType=0);background-repeat:repeat-x}.panel-primary>.panel-heading{background-image:-webkit-linear-gradient(top,#428bca,#357ebd);background-image:-webkit-gradient(linear,left top,left bottom,from(#428bca),to(#357ebd));background-image:linear-gradient(180deg,#428bca 0,#357ebd);background-repeat:repeat-x}.panel-success>.panel-heading{background-image:-webkit-linear-gradient(top,#dff0d8,#d0e9c6);background-image:-webkit-gradient(linear,left top,left bottom,from(#dff0d8),to(#d0e9c6));background-image:linear-gradient(180deg,#dff0d8 0,#d0e9c6);background-repeat:repeat-x}.panel-info>.panel-heading{background-image:-webkit-linear-gradient(top,#d9edf7,#c4e3f3);background-image:-webkit-gradient(linear,left top,left bottom,from(#d9edf7),to(#c4e3f3));background-image:linear-gradient(180deg,#d9edf7 0,#c4e3f3);background-repeat:repeat-x}.panel-warning>.panel-heading{background-image:-webkit-linear-gradient(top,#fcf8e3,#faf2cc);background-image:-webkit-gradient(linear,left top,left bottom,from(#fcf8e3),to(#faf2cc));background-image:linear-gradient(180deg,#fcf8e3 0,#faf2cc);background-repeat:repeat-x}.panel-danger>.panel-heading{background-image:-webkit-linear-gradient(top,#f2dede,#ebcccc);background-image:-webkit-gradient(linear,left top,left bottom,from(#f2dede),to(#ebcccc));background-image:linear-gradient(180deg,#f2dede 0,#ebcccc);background-repeat:repeat-x}.well{background-image:-webkit-linear-gradient(top,#e8e8e8,#f5f5f5);background-image:-webkit-gradient(linear,left top,left bottom,from(#e8e8e8),to(#f5f5f5));background-image:linear-gradient(180deg,#e8e8e8 0,#f5f5f5);background-repeat:repeat-x;border-color:#dcdcdc;-webkit-box-shadow:inset 0 1px 3px rgba(0,0,0,.05),0 1px 0 hsla(0,0%,100%,.1);box-shadow:inset 0 1px 3px rgba(0,0,0,.05),0 1px 0 hsla(0,0%,100%,.1)}html{font-family:sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}article,aside,details,figcaption,figure,footer,header,hgroup,main,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block;vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}a:active,a:hover{outline:0}abbr[title]{border-bottom:1px dotted}b,optgroup,strong{font-weight:700}dfn{font-style:italic}h1{margin:.67em 0}mark{color:#000;background:#ff0}small{font-size:80%}sub,sup{position:relative;font-size:75%;line-height:0;vertical-align:baseline}sup{top:-.5em}sub{bottom:-.25em}img{border:0;vertical-align:middle}svg:not(:root){overflow:hidden}hr{height:0;-webkit-box-sizing:content-box;box-sizing:content-box}pre,textarea{overflow:auto}code,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}button,input,optgroup,select,textarea{margin:0;font:inherit;color:inherit}button{overflow:visible}button,select{text-transform:none}button,html input[type=button],input[type=reset],input[type=submit]{-webkit-appearance:button;cursor:pointer}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}input{line-height:normal}input[type=checkbox],input[type=radio]{-webkit-box-sizing:border-box;box-sizing:border-box;padding:0}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{height:auto}input[type=search]{-webkit-box-sizing:content-box;box-sizing:content-box;-webkit-appearance:textfield}input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration{-webkit-appearance:none}fieldset{padding:.35em .625em .75em;margin:0 2px;border:1px solid silver}legend{padding:0;border:0}table{border-spacing:0;border-collapse:collapse}td,th{padding:0}@media print{*{color:#000!important;text-shadow:none!important;background:0 0!important;-webkit-box-shadow:none!important;box-shadow:none!important}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}a[href^="#"]:after,a[href^="javascript:"]:after{content:""}blockquote,pre{border:1px solid #999;page-break-inside:avoid}thead{display:table-header-group}img,tr{page-break-inside:avoid}img{max-width:100%!important}h2,h3,p{orphans:3;widows:3}h2,h3{page-break-after:avoid}select{background:#fff!important}.navbar{display:none}.table td,.table th{background-color:#fff!important}.btn>.caret,.dropup>.btn>.caret{border-top-color:#000!important}.label{border:1px solid #000}.table{border-collapse:collapse!important}.table-bordered td,.table-bordered th{border:1px solid #ddd!important}}*,:after,:before{-webkit-box-sizing:border-box;box-sizing:border-box}html{font-size:62.5%;-webkit-tap-highlight-color:transparent}body{margin:0;font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff}button,input,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit}a{background:0 0;color:#428bca;text-decoration:none}a:focus,a:hover{color:#2a6496;text-decoration:underline}a:focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}figure{margin:0}.carousel-inner>.item>a>img,.carousel-inner>.item>img,.img-responsive,.thumbnail>img,.thumbnail a>img{display:block;max-width:100%;height:auto}.img-rounded{border-radius:6px}.img-thumbnail{display:inline-block;max-width:100%;height:auto;padding:4px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:.2s ease-in-out;transition:.2s ease-in-out}.img-circle{border-radius:50%}hr{margin-top:20px;margin-bottom:20px;border:0;border-top:1px solid #eee}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{font-family:inherit;font-weight:500;line-height:1.1;color:inherit}.h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,.h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{font-weight:400;line-height:1;color:#999}.h1,.h2,.h3,h1,h2,h3{margin-top:20px;margin-bottom:10px}.h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small{font-size:65%}.h4,.h5,.h6,h4,h5,h6{margin-top:10px;margin-bottom:10px}.h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{font-size:75%}.h1,h1{font-size:36px}.h2,h2{font-size:30px}.h3,h3{font-size:24px}.h4,h4{font-size:18px}.h5,h5{font-size:14px}.h6,h6{font-size:12px}p{margin:0 0 10px} </style><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script><script async src="/js_v1560415138/adaptive/bootstrap.js"></script><!--[if lte IE 9]>
    <script async src="/js_v1560415138/adaptive/html5.js"></script>
    <script async src="/js_v1560415138/adaptive/html5shiv.js"></script>
    <script async src="/js_v1560415138/adaptive/respond.js"></script>
    <script async src="/js_v1560415138/adaptive/ie-bootstrap-carousel.js"></script>
    <![endif]--><!--[if IE 8]>
    <link href="/styles_v1560415138/adaptive/ie8.css" rel="stylesheet" media="all"/><![endif]--><!--[if IE 7]>
    <link href="/styles_v1560415138/adaptive/ie7.css" rel="stylesheet" media="all"/><![endif]--><script src="/js_v1560415138/adaptive/bootstrap.min.js"></script>   <!--[if gt IE 7]>
    <link href="/styles_v1560415138/style_ie_all.css" media="screen" rel="stylesheet" type="text/css"/>
    <![endif]--><!--[if lt IE 7]>
    <link href="/styles_v1560415138/style_ie6.css" media="screen" rel="stylesheet" type="text/css"/>
    <script async src="/scripts_v1560415138/dd_belatedpng.js" type="text/javascript"></script>
    <script async type="text/javascript">DD_belatedPNG.fix("img, div, a, span, ul, p, input");</script>
    <![endif]--><!--[if IE]>
    <style type="text/css">.titleExtras, a.use, a.use span {
        behavior: url(/styles/PIE.htc);</style>
    <![endif]--><!--[if IE 6]>
    <script async src="scripts/DD_belatedPNG.js"></script>
    <script async type="text/javascript">DD_belatedPNG.fix(".live_supp, .leftmenu li a, .girl");</script>
    <![endif]--><script>!function(e,t,n,c,o,a,f){e.fbq||(o=e.fbq=function(){o.callMethod?o.callMethod.apply(o,arguments):o.queue.push(arguments)},e._fbq||(e._fbq=o),(o.push=o).loaded=!0,o.version="2.0",o.queue=[],(a=t.createElement(n)).async=!0,a.src="https://connect.facebook.net/en_US/fbevents.js",(f=t.getElementsByTagName(n)[0]).parentNode.insertBefore(a,f))}(window,document,"script"),fbq("init","1706090589711754"),fbq("track","PageView")</script><noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1706090589711754&ev=PageView&noscript=1"/></noscript><link rel="apple-touch-icon" sizes="57x57" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-57x57.png"><link rel="apple-touch-icon" sizes="60x60" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-60x60.png"><link rel="apple-touch-icon" sizes="72x72" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-72x72.png"><link rel="apple-touch-icon" sizes="76x76" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-76x76.png"><link rel="apple-touch-icon" sizes="114x114" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-114x114.png"><link rel="apple-touch-icon" sizes="120x120" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-120x120.png"><link rel="apple-touch-icon" sizes="144x144" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-144x144.png"><link rel="apple-touch-icon" sizes="152x152" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-152x152.png"><link rel="apple-touch-icon" sizes="180x180" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-icon-180x180.png"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="bestessays.com"><meta name="mobile-web-app-capable" content="yes"><meta name="theme-color" content="#fff"><meta name="application-name" content="bestessays.com"><link rel="icon" type="image/png" sizes="32x32" href="/build/icons-2ff7e2b756984cf0927329a004210003/favicon-32x32.png"><link rel="icon" type="image/png" sizes="16x16" href="/build/icons-2ff7e2b756984cf0927329a004210003/favicon-16x16.png"><link rel="shortcut icon" href="/build/icons-2ff7e2b756984cf0927329a004210003/favicon.ico"><link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 1)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-320x460.png"><link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-640x920.png"><link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-640x1096.png"><link rel="apple-touch-startup-image" media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-750x1294.png"><link rel="apple-touch-startup-image" media="(device-width: 414px) and (device-height: 736px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 3)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1182x2208.png"><link rel="apple-touch-startup-image" media="(device-width: 414px) and (device-height: 736px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 3)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1242x2148.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 1)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-748x1024.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 1)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-768x1004.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1496x2048.png"><link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 2)" href="/build/icons-2ff7e2b756984cf0927329a004210003/apple-touch-startup-image-1536x2008.png"><link href="/build/adaptive.3dba1394b914ec12b317.bundle.css" rel="stylesheet"><link rel="preload" href="/build/adaptive.3dba1394b914ec12b317.bundle.css" as="style"></head><body><div id="fb-root"></div><script>!function(e,t,n){var c,o=e.getElementsByTagName(t)[0];e.getElementById(n)||((c=e.createElement(t)).id=n,c.src="//connect.facebook.net/ru_RU/all.js#xfbml=1",o.parentNode.insertBefore(c,o))}(document,"script","facebook-jssdk")</script><div class="login_layer"><div class="container"><div class="login_container"><div class="title-login mobile">Please, login</div><form id="loginbox" method="post" action="/customer/login/" class="login_form"><div class="cancel"></div><div class="input text"><label><span>Login:</span><br/><input aria-label="login" id="login_email" name="email"></label></div><div class="input text"><label><span>Password:</span><br/></label> <input type="password" id="pass" aria-label="password" name="pass"></div><input name="remember_me" id="remember_me" type="checkbox" checked="checked"><label for="remember_me" class="remember_me_label">Remember me</label><div class="login_button"><a href="/forgot.html">Forgot password?</a> <button onclick='checkform(document.getElementById("loginbox"))' class="button" type="submit">Login</button></div></form></div></div></div><header><div class="mobile mobile-logo"><a href="/"><img src="/images/customer/mobile-logo.png" alt="BestEssays"></a></div><nav class="hi_top_menu"><div class="mobile-btn mobile-menu"></div><div class="container"><ul class="clearfix"><div class="pull-left-mobile"><li><a href="/">Home</a></li><li><a href="/our-services.php">Services</a></li><li><a href="/prices.php">Prices</a></li><li><a href="/order">Order</a></li><li><a href="/get-great-discounts.php">Discounts</a></li><li class="hidden-xs"><a href="/samples.php">Samples</a></li><li class="hidden-xs"><a href="/aboutus.php">About Us</a></li><li class="hidden-xs"><a href="/customersupport.php">Contacts</a></li></div><div class="pull-right">  <a href="javascript:void(0)" class="button login_opener">Login</a>  </div></ul><div class="mobile-close">X</div></div>  <div class="mobile-btn mobile-login"></div>  </nav><div class="container logo-block">          <div class="logo-block">
    <div class="center-wrapper">
        <div class="flex-wrapper">
            <div class="logo-block__logo">
                <a href="/">
                    <img src="/images/img-home/split/logo.png" alt="">
                </a>
            </div>
            <div class="logo-block__support">
                <div class="fb-messager">
                    <a class="fb-messager__link" href="https://m.me/bestessayscom" target="_blank">
                        <img class="fb-messager__img" src="//img2.bestessays.com/buttons/facebook-messenger-1%401X.png">
                        <p class="fb-messager__text">Message us</p>
                    </a>
                </div>
                <a href="#" onclick="chat = document.querySelector('.bc-minimize-state');!!chat?chat.click():document.querySelector('.bcFloat a').click();return false;">Live Chat <span> online</span></a>
                <a href="tel:+1-888-533-4942">+1-888-533-4942</a>
            </div>
        </div>
    </div>
</div>    
 
<nav class="main_menu">
	<ul class="topmenu">
														<li class="first" >
				<a href="/doc_essay.php"><span>Essay</span></a>

				</li>
																	<li  >
				<a href="/custom_research_paper.php"><span>Research<br>Paper</span></a>

				</li>
																	<li  >
				<a href="/coursework.php"><span>Coursework</span></a>

				</li>
																	<li  >
				<a href="/custom_term_paper.php"><span>Term Paper</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/casestudy.php"><span>Case Study</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/dissertation-services.php"><span>Dissertation Services</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/admission-application-essay.php"><span>Admission<br>Services</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="https://www.resumesplanet.com" rel="nofollow"><span>Resume</span></a>

				</li>
																	<li  class="hidden-xs">
				<a href="/extras.php"><span>Extras</span></a>

				</li>
																																																																	        <li class="hidden-sm hidden-md hidden-lg">
            <a href="/our-services.php">More</a>
        </li>
	</ul>
</nav>

         <style>
.firstTime#dynamicBanner{
background:url("//img2.bestessays.com/ukfacebook/bg_block_new.png") no-repeat;
}
.mainBanner{
max-width:720px!important;
padding-right:0!important;
}
</style>    
 </div></header><div id="body_content"><div class="content"><section class="fe_content container"><div class="container"><div class="right_colomn">  <div class="fe_content fq_content container">
<h1>FAQs</h1>
<h3>Order Process</h3>
<div id="fq_list1" class="panel-group fq_colaps">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapse collapsed" href="#fq_list1_line1" data-parent="#fq_list1" data-toggle="collapse">                                 How do I place an order with your company?                             </a></h4>
</div>
<div style="height: 0px;" class="panel-collapse collapse" id="fq_list1_line1">
<div class="panel-body">To place your order, simply follow <a href="/order/">this link</a> to the order page. Provide us your complete contact information and give us the phone numbers where you can be reached in case of any questions or problems.</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list1_line2" data-parent="#fq_list1" data-toggle="collapse">                                 How can I upload files needed by the writer?                             </a></h4>
</div>
<div style="height: 0px;" class="panel-collapse collapse" id="fq_list1_line2">
<div class="panel-body">Once an order is placed, you are to choose one of the most suitable ways to provide writer with additional instructions and materials. You are welcome to take advantage of our interactive features and upload additional files from your personal profile on our web site. Some of our clients prefer transferring files in our Live Chat while communicating with one of our operators. You may also send all additional instructions to our email support (at) bestessays.com with the order number indicated in the topic of the letter or fax them with your order number written on the cover sheet of the faxed document and our qualified Support team will attach them to your order. You can find our contact information <a href="/customersupport.php">here</a></div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list1_line3" data-parent="#fq_list1" data-toggle="collapse">                                 What if I can't provide the references needed to write the paper, can you, guys, make the research for me?                             </a></h4>
</div>
<div style="height: 0px;" class="panel-collapse collapse" id="fq_list1_line3">
<div class="panel-body">We provide our writers with accounts to online libraries and they are able to do the research for you. However, if possible, please do not neglect uploading all the material that might be helpful and properly instruct a writer to make sure that very little time is wasted on research.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list1_line4" data-parent="#fq_list1" data-toggle="collapse">                                 How can I monitor the progress of my order?                             </a></h4>
</div>
<div style="height: 0px;" class="panel-collapse collapse" id="fq_list1_line4">
<div class="panel-body">Your order status is updated on constant basis automatically on your personal profile on the website. There are also multiple ways to contact our qualified Support team and your writer to monitor your order progress. You are welcome to take advantage of our unique messaging system, available for you after the order is placed, to ask your writer directly. You may also go to Live Chat, call our Support team on our toll free numbers or email with any concern you have. We will gladly assist and update you regarding your order.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list1_line5" data-parent="#fq_list1" data-toggle="collapse">                                 Can I request a draft from my writer?                             </a></h4>
</div>
<div style="height: 0px;" class="panel-collapse collapse" id="fq_list1_line5">
<div class="panel-body">You can ask for a draft from your writer. Just make sure you mention this in order description. You may also send a request to a writer via messaging system and inform our qualified Support team so we could make sure you receive it in a timely manner.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list1_line6" data-parent="#fq_list1" data-toggle="collapse">                                 How long will it take to write my essay?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list1_line6">
<div class="panel-body">We use a honest and realistic approach to deadlines. The delivery time depends on your instructions, the urgency level of your order and the level of writer you choose. Experience tells us that we can write most orders within 24 hours. However we suggest that you place your order as soon as possible to give us extra time in case we need to do more research. If we can not meet your deadline or if it requires extra time we will call you to discuss your order. We will take whatever steps necessary to fill your order on time guaranteed.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list1_line7" data-parent="#fq_list1" data-toggle="collapse">                                 How will I get my paper?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list1_line7">
<div class="panel-body">Once an order is placed, you will have a possibility to log in to your personal profile on the web site. The completed paper can be downloaded from there. You can also request the paper to be sent directly to your email.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list1_line8" data-parent="#fq_list1" data-toggle="collapse">                                 Can you make changes in order requirements before it is done in case my professor changes the instructions?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list1_line8">
<div class="panel-body">We are working hard to meet your requirements and expectations. That is why you are allowed to apply amendments to your order free of charge as long as they don't violate original instructions.</div>
</div>
</div>
</div>
<h3>Our Writers</h3>
<div id="fq_list2" class="panel-group fq_colaps">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a href="#fq_list2_line1" data-parent="#fq_list2" data-toggle="collapse">                                 What are the qualifications of your writers?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list2_line1">
<div class="panel-body">We employ a large and diverse team of writers, teachers and professors, who undergo a strict selection procedure in order to join our team. Their performance is monitored and evaluated by our Quality Assurance Department to provide you with the best essay writing services.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a href="#fq_list2_line2" data-parent="#fq_list2" data-toggle="collapse">                                 How can I be sure that you have a specialized writer to work on my order?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list2_line2">
<div class="panel-body">We employ more than seven hundred writers, editors and researchers. Most of them hold at least a Masters Degree and enjoy challenging assignments in their respective fields. Our employees work in the mode of selection - they choose the orders to work on themselves and we approve the best suitable writer from those who are interested to work on it. This way we can guarantee that your order is taken by a writer who is not only willing to work on your order, but is also proficient enough in your subject area.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a href="#fq_list2_line3" data-parent="#fq_list2" data-toggle="collapse">                                 Can I communicate with my writer to make sure he understands my instructions well?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list2_line3">
<div class="panel-body">We are always improving our system to provide you with the best customer service possible: you can correspond with your writer, track your order status and upload any additional material 24/7. Once you place an order with us and a writer is assigned, you will have an opportunity to communicate with your writer through our unique messaging system. This is one of our interactive features that you are welcome to use to get in touch with the writer or our qualified Support team. It is an easy way to find out about the order progress, exchange resources and other essential data with your writer.</div>
</div>
</div>
</div>
<h3>Our Services</h3>
<div id="fq_list3" class="panel-group fq_colaps">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a href="#fq_list3_line1" data-parent="#fq_list3" data-toggle="collapse">                                 What are your services and pricing policy?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list3_line1">
<div class="panel-body">We offer custom writing, editing, proofreading and formatting services for students of all ages and majors including students pursuing their Bachelor's, Master's, Doctorate or a Professional degree. Our services consist of ten different urgency levels and three levels of professional writers.
<ul>
    <li>3 hours</li>
    <li>6 hours</li>
    <li>12 hours</li>
    <li>24 hours</li>
    <li>48 hours</li>
    <li>3 days</li>
    <li>4 days</li>
    <li>5 days</li>
    <li>7 days</li>
    <li>10 days</li>
</ul>
You can choose the quality level you require. There are three quality levels to choose from. The higher the price, the more superior the level of your researcher and the sooner your order will be delivered. Our Standard Quality writing level is widely used for simple writing assignments at any level and is best suited for assignments at Pre-Bachelor and for some Bachelor degrees. Our Premium Quality level is intended for the students who are pursuing their Bachelor's and some Master's degrees. Our Platinum level fits most students who are pursuing Master's and MBA degrees or specialized degrees such as Law, Biology, or Finance or other research intensive assignments. This level is recommended for courses that require extraordinary research and skill.                             - See more at: https://www.bestessays.com/custompaperfaq.php#how_do_i_place</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a href="#fq_list3_line2" data-parent="#fq_list3" data-toggle="collapse">                                 Can you help me with my essay, term paper or dissertation?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list3_line2">
<div class="panel-body">Yes, our company has over seven hundred professional researchers, writers and editors in a wide variety of academic fields. We can write even the most difficult and unique essays. Our professional writers have years of writing experience and can write outstanding works for any academic level regardless of length, subject or style. High school, Bachelor's, Master's or PhD we have the experience you need.</div>
</div>
</div>
</div>
<h3>Confidentiality, Security, Guarantees</h3>
<div id="fq_list4" class="panel-group fq_colaps">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list4_line1" data-parent="#fq_list4" data-toggle="collapse">                                 Will I get my paper on time?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list4_line1">
<div class="panel-body">As a commitment to quality and excellence, we are striving hard to serve our best and provide our customers with the best service possible. We make sure every order meets your expectation and is completed within the deadline. However, please make sure that your order is correctly placed and all additional information needed for its completion is uploaded in time so that the writer had no obstacles to finish the paper within the deadline.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list4_line2" data-parent="#fq_list4" data-toggle="collapse">                                 Can you assure me that my paper is plagiarism free?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list4_line2">
<div class="panel-body">Every order is checked by the most advanced anti-plagiarism software in the market to assure your assignment is 100% original. We have a zero tolerance policy for plagiarism. Any writer who is caught violating these terms will be terminated immediately</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list4_line3" data-parent="#fq_list4" data-toggle="collapse">                                 Do you offer guarantee for your services?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list4_line3">
<div class="panel-body">Our philosophy is to understand the needs of our clients and meet or exceed expectations. Many of our writers are current or former teachers and professors who have the knowledge and real life expertise. Not only do they understand what is expected from an academic standpoint, but they are assigned only to subjects of their exact experience. We take pride in what we do and we guarantee your satisfaction.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list4_line4" data-parent="#fq_list4" data-toggle="collapse">                                 What if I am not happy with the paper?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list4_line4">
<div class="panel-body">We are here to make sure you receive the paper that is up to your requirements. Our qualified Support is here for you 24/7 and we will gladly assist you in any amendments. Therefore, if you are not fully satisfied with the paper, you can request a revision an unlimited number of times within 14 days after order completion free of charge. All you need to do is to press the Request Revision button in order details from your personal profile on the web site and fill in revision instructions box with your further requests. However, you need to make sure those correspond to your initial requirements and do not violate our Terms and Conditions. We value our Customers and believe it is our duty to make sure that you are fully satisfied with the service</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list4_line5" data-parent="#fq_list4" data-toggle="collapse">                                 Can I be confident in confidentiality and privacy of your services?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list4_line5">
<div class="panel-body">Your privacy and security are our highest priorities. Other companies trade and sell your personal information. We guarantee total confidentiality of your personal information and that your personal information will never be sold. Your details will not be disclosed under any circumstances. We respect and maintain the privacy of every customer.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list4_line6" data-parent="#fq_list4" data-toggle="collapse">                                 How secure is the transaction process? Do you store my credit card data?                             </a></h4>
</div>
<div style="height: 0px;" class="panel-collapse collapse" id="fq_list4_line6">
<div class="panel-body">We transmit your sensitive data using the industry standard secure process to Authorize.net using 128 (bit) encryption. We use the leaders in security business processing. Our transaction process is guaranteed to be authentic and insured up to $10,000 by the Comodo Group. Click the secure logo on the payment page to confirm your information.</div>
</div>
</div>
</div>
<h3>General Questions</h3>
<div id="fq_list5" class="panel-group fq_colaps">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list5_line1" data-parent="#fq_list5" data-toggle="collapse">                                 Can I get a discount?                             </a></h4>
</div>
<div style="height: 0px;" class="panel-collapse collapse" id="fq_list5_line1">
<div class="panel-body">Kindly go to the Discount page for more information . There you may check if you are eligible for any of our current discounts. You can also contact our Support Team for detailed instructions.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list5_line2" data-parent="#fq_list5" data-toggle="collapse">                                 What are the advantages of your writing service?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list5_line2">
<div class="panel-body">Our company is committed to quality and excellence. We revamped our customer service system to provide you with the best service possible. You can now communicate with your writer, view and track your order status, upload instructions, research materials, do billing verification, and download your assignment 24 hours a day, 365 days a year. To ensure our quality we implemented a more rigorous hiring process for new writers and started a proprietary writer match system to match your orders with the best writer. Our target goal is to hire 10 qualified writers to join our team every month to accommodate growth, eliminate problems with orders, and improve paper quality. In addition to these new features we also offer you phone and chat support 24 hours a day!</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list5_line3" data-parent="#fq_list5" data-toggle="collapse">                                 How are you different from other essay writing companies?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list5_line3">
<div class="panel-body">Our writing service delivers the highest quality custom papers and we have the experienced professionals to back it up. We make every effort to be the leader in the industry and prove it by providing more than just quality service. We provide you with peace of mind. Do not be misled by sites of unknown origin who promise quality papers for very little money. Even the best online essay writers can't write papers within an hour for meager pay. You can find other reasons here.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list5_line4" data-parent="#fq_list5" data-toggle="collapse">                                 What if I need a large order with allot of pages in a short period of time? Why is this option disabled?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list5_line4">
<div class="panel-body">Our writers and research professionals need time to produce a quality document. In some cases it is virtually impossible to complete certain orders in such a short period of time. If you need a dissertation you may place several different orders for individual chapters and have several writers complete your assignment. We provide only original writing and research unlike many companies who claim they can write large orders in such a short period of time. Please contact us if you have any questions about your order.</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list5_line5" data-parent="#fq_list5" data-toggle="collapse">                                 What is your refund policy?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list5_line5">
<div class="panel-body">We proudly offer you a 100% satisfaction guarantee. If you are not completely satisfied with your paper you can request a revision within 15 days (30 days for dissertations and theses) and we will revise it FREE of charge until you are satisfied that your initial requirements were met. If you are not satisfied with the essay, you can request a refund in writing so long as it is no later than three days after your order was completed. In fact we have the highest percentage of satisfied clients in the industry. This shows our commitment to customer satisfaction. We take great pride in delivering you the highest quality service possible. Thank you for choosing Bestessays.com</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title"><a class="collapsed" href="#fq_list5_line6" data-parent="#fq_list5" data-toggle="collapse">                                 Are you a US registered company?                             </a></h4>
</div>
<div class="panel-collapse collapse" id="fq_list5_line6">
<div class="panel-body">We are officially registered with the US Government as a business entity and take great pride in providing a legitimate writing service. We have several different office locations and our main office is located in Delaware. Our company has years of proven successful experience.</div>
</div>
</div>
</div>
</div>
</div>  </div>  <div class="left_column hidden-xs hidden-sm">          <h4>FREE features in every order</h4>
<div class="free_features">
<div>
<div>FREE</div>
</div>
<table>
    <tbody>
        <tr>
            <td>Outline</td>
            <td>$5</td>
        </tr>
        <tr>
            <td>Amendments*</td>
            <td>$30</td>
        </tr>
        <tr>
            <td>Title Page</td>
            <td>$5</td>
        </tr>
        <tr>
            <td>Bibliography</td>
            <td>$15</td>
        </tr>
        <tr>
            <td>Formatting</td>
            <td>$10</td>
        </tr>
        <tr>
            <td><strong>Total savings:</strong></td>
            <td><strong>$65</strong></td>
        </tr>
    </tbody>
</table>
<p>(*Provided upon request)</p>
</div>
<div class="left_column_our_guarantee">
<h5>Our guarantees</h5>
<p><strong>Satisfaction guarantee</strong> - free amendments are available upon request</p>
<p><strong>100% original writing</strong> - all papers are written from scratch by your request</p>
<p><strong>Deadline meeting guarantee</strong> - even 3-hr delivery is available</p>
<p><strong>Confidentiality guarantee</strong> - your information is not disclosed to any third part</p>
<p><strong>24/7 support guarantee</strong> - we are available any time day or night</p>
<p><strong>Money-back guarantee</strong> - just negotiate all issues with support</p>
</div>    
  </div></div></section></div></div>          <footer>
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-lg-8 col-sm-12 col-xs-5">
                <div class="row bottom_links">
                    <div class="col-md-4 col-sm-4">
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="/prices.php">Prices</a></li>
                            <li><a href="/order">Order custom essay</a></li>
                            <li><a href="/samples.php">Sample Essays</a></li>
                            <li><a href="/custom_term_paper.php">Custom term paper</a></li>
                            <li><a href="/affiliate.php/">Affiliate program</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <ul>
                            <li><a href="/doc_essay.php">Custom essay</a></li>
                            <li><a href="/custom_research_paper.php">Research paper</a></li>
                            <li><a href="/write-my-essay.php">Write my essay</a></li>
                            <li><a href="/essay_writers.php">Essay writers</a></li>
                            <li><a href="/custom_writing.php">Writing Process</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <ul>
                            <li><a href="/customersupport.php">Contact us</a></li>
                            <li><a href="/glossary.php">Glossary</a></li>
                            <li><a href="/disclaimer.php">Terms and conditions</a></li>
                            <li><a href="/privacy_policy.php">Privacy policy</a></li>
                            <li><a href="/sitemap.php">Sitemap</a></li>
                            <li><a href="/custompaperfaq.php ">FAQ</a></li>
                        </ul>
                    </div>
                </div>

                <div class="row hidden-xs footer_contacts">
                    <div class="col-md-3 col-sm-3">
                       <h6>US Sales Toll-Free</h6>
                       <p>+1-888-533-4942</p>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <h6>US Support Toll-Free</h6>
                        <p>+1-888-357-6549</p>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <h6>UK Toll Free</h6>
                        <p>+44-808-189-1011</p>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <h6>AU Toll Free</h6>
                        <p>+61-1-800-704995</p>
                    </div>
                </div>
            </div>
            <div class=" visible-xs col-xs-7 footer_contacts">
                <div class="col-md-3 col-sm-3">
                    <h6>US Sales Toll-Free</h6>
                    <p>1-888-533-4942</p>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h6>US Support Toll-Free</h6>
                    <p>1-888-357-6549</p>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h6>UK Toll Free</h6>
                    <p>+44-808-189-1011</p>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h6>AU Toll Free</h6>
                    <p>+61-1-800-704995</p>
                </div>
            </div>
            <div class="payment_wrapper hidden-sm ">
                <div class="row payment_container">
                    <div class="left_part">
                        <a class="payment_1" href="javascript:void(0);"></a>
                        <a class="payment_2" href="javascript:void(0);"></a>
                        <a class="payment_3" href="javascript:void(0);"></a>
                        <a class="payment_4" href="javascript:void(0);"></a>
                        <a class="payment_5" href="javascript:void(0);"></a>
                    </div>
                    <div class="right_part">
                        <p>All payments are securely processed by</p>
                        <a href="https://www.securitymetrics.com/site_certificate.adp?s=bestessays%2ecom&i=1230177"></a>
                    </div>
                </div>
                
            </div>

        </div>
        <div class="row payment_container tablet_variant visible-sm">
            <div class="left_part">
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <a href="javascript:void(0);"></a>
                <!--<a href="javascript:void(0);"></a>-->
            </div>
            <div class="right_part">
                <a href="https://www.securitymetrics.com/site_certificate.adp?s=bestessays%2ecom&i=1230177">
                </a>
                <p>All payments are securely processed</p>
            </div>
        </div>
        <p class="hidden-xs"> 1997-<script>d = new Date();document.write(d.getFullYear());</script> "BestEssays.com"</p>
    </div>
</footer>
<section class="disclamer">
    <div class="disclamer_text"></div>
</section>


<script>
var banner = (function () {
    function removeClass(el,classNm) {
        var currClass = el.getAttribute('class');
        var classResult = currClass.replace(classNm,'');
        el.setAttribute('class',classResult);
    };
    function addClass(el,classNm) {
        el.setAttribute('class',el.className+' '+classNm);
    };
    function hasClass(el,classNm) {
        var currClass = el.getAttribute('class') || '';
        if (currClass.indexOf(classNm) != -1) {
            return true;
        } else {
            return false;
        }
    };
    function cookieExists(cookieName) {
        return (document.cookie.indexOf(cookieName) != -1) ? true : false;
    };
    function init(bannerUniqueID,buttonUniqueID,cookie) {
        var $banner = $(bannerUniqueID),
    $button = $(buttonUniqueID),
    $textAfter = $(buttonUniqueID + ' + h6');
if (cookieExists(cookie) === true) {
    $button.add($banner).removeClass('firstTime');
    $banner.attr({
        href: '/order/',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'discount_banner_old_customers_new_design', '']);"
    });
    $button.attr({
        href: '/order/',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'top_button_old_customers_new_design', '']);"
    });
    $button.html('REQUEST PAPER NOW');
    $textAfter.hide();
} else {
    $banner.addClass('firstTime');
    $banner.attr({
        href: '/order/?promo=begin15',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'banner_15off_new_design', '']);"
    });
    $button.addClass('firstTime');
    $button.attr({
        href: '/order/?promo=begin15',
        onclick: "_gaq.push(['_trackEvent', 'Button', 'top_button_15off_new_design', '']);"
    });
    $button.html('Try service with <strong>15% discount*</strong>');
    $textAfter.show();
}
    };
    return {
        check : init
    }
}());
</script> <script>banner.check('#dynamicBanner','#dynamicLink','_hpo');	</script>

<div class="wrapper-email-popup">
<div class="shadow-wrapp"></div>
<div class="block-email-popup">
<div class="close-email-popup"><img src="/images/cls-but.jpg" alt="X"></div>
<div class="wrapper-form">
<form class="email-form" action="#" method="POST">
<div class="wrap-input-field">
<label for="name-user-email">Your name:</label>
<input id="name-user-email" type="text"><div class="error-message">Enter your name</div>
</div>
<div class="wrap-input-field">
<label for="email-user">Email:</label>
<input id="email-user" type="text"><div class="error-message">Enter valid email address</div>
</div>
<div class="wrap-input-field"><input id="send-email" value="Apply" type="button"></div>
</form>
</div>
<div class="thank-block">
<div class="title-thank">Thank you.</div><p>Our representatives will contact<br>you within 24 hours.</p>
</div>
</div>
</div>
    
          <!-- BoldChat Conversion Tracking HTML v5.10 (Website=www.bestessays.com,ConversionCode=test conversion code) -->
<script type="text/javascript">
    window._bcvma = window._bcvma || [];
    _bcvma.push(["setAccountID", "161178856198874968"]);
    _bcvma.push(["addConversion", {
      ConversionAmount: dataLayer[0].transactionTotal,
      ConversionRef: dataLayer[0].transactionId,
      ConversionInfo: "",
      WebsiteID: "1985431959216183439",
      ConversionCodeID: "3070130503748985491"
    }]);
  var bcLoad = function(){
    if(window.bcLoaded) return; window.bcLoaded = true;
    var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
    vms.src = ('https:'==document.location.protocol?'https://':'https://') + "vmss.boldchat.com/aid/161178856198874968/bc.vms4/vms.js";
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
  };
  if(window.pageViewer && pageViewer.load) pageViewer.load();
  else bcLoad();</script>
<noscript>
<a href="https://www.boldchat.com" title="Live Chat Software" target="_blank"><img alt="Live Chat Software" src="https://vms.boldchat.com/aid/161178856198874968/bc.vci?wdid=1985431959216183439&ccid=3070130503748985491&ca=&cr=&ci=" border="0" width="1" height="1" /></a>
</noscript>
<!-- /BoldChat Conversion Tracking HTML v5.10 -->
    
          <style>
.bcFloat{
bottom:0!important;
right:0!important;
top:auto!important;
left:auto!important;
position:fixed!important;
}
</style>
<!-- BoldChat Visitor Monitor HTML v5.00 (Website=www.bestessays.com,ChatButton=Dev button float,ChatInvitation=MAIN RULE SET) -->
<script type="text/javascript">
  window._bcvma = window._bcvma || [];
  _bcvma.push(["setAccountID", "161178856198874968"]);
  _bcvma.push(["setParameter", "WebsiteID", "1985431959216183439"]);
  _bcvma.push(["setParameter", "VisitInfo", dataLayer[0].userId]);
  _bcvma.push(["setParameter", "InvitationID", "5014589077779556438"]);
  _bcvma.push(["addFloat", {type: "chat", id: "3771936857143385943"}]);
  _bcvma.push(["pageViewed"]);
  var bcLoad = function(){
    if(window.bcLoaded) return; window.bcLoaded = true;
    var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
    vms.src = ('https:'==document.location.protocol?'https://':'https://') + "vmss.boldchat.com/aid/161178856198874968/bc.vms4/vms.js";
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
  };
  if(window.pageViewer && pageViewer.load) pageViewer.load();
  else if(document.readyState=="complete") bcLoad();
  else if(window.addEventListener) window.addEventListener('load', bcLoad, false);
  else window.attachEvent('onload', bcLoad);
</script>
<noscript>
<a href="https://www.boldchat.com" title="Live Chat Software" target="_blank"><img alt="Live Chat Software" src="https://vms.boldchat.com/aid/161178856198874968/bc.vmi?wdid=1985431959216183439&vi=userID&curl=" border="0" width="1" height="1" /></a>
</noscript>
<!-- /BoldChat Visitor Monitor HTML v5.00 -->
    
          <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MTC9MMT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    
  <script async src="//rum-static.pingdom.net/pa-59f072b5f3f14ae82c7b23c6.js"></script><script src="/build/adaptive.263784e454a851df9e21.js" async></script>
<style>
.cookies {
  position: fixed;
  bottom: 0;
  z-index: 999999998;
  background: rgba(255, 255, 255, 0.85);
  width: 100%;
  color: #fff;
  text-align: center;
  display: none;
  left: 0;
  border-top: 1px solid #ddd;
  padding: 0 220px 0 20px;
  box-sizing: border-box;
}
#accept_cookie_window .cookies_text {
    margin: 10px auto;
    position: relative;
    color: #000;
    text-align: center;
    font-size: 12px;
    font-family: Arial, sans-serif;
    padding: 0;
    line-height: 1.3;
    box-sizing: border-box;
}
.cookies__close {
  cursor: pointer;
  display: inline-block;
  background: #C4D7ED;
  padding: 2px 4px;
  border-radius: 5px;
  margin-left: 10px;
}
.cookies__close:hover {
  background: #9bc3f1;
  color: #353535;
}
.bcFloat {
  z-index: 999999999 !important;
}
.cookies br {
  display: none;
}
@media all and (max-width: 1480px) {
  .cookies {
    padding: 0 0 0 20px;
  }
  #accept_cookie_window .cookies_text {
    padding-right: 200px;
  }
  .cookies .cookies-br__second {
    display: inline;
  }
}
@media all and (max-width: 1100px) {
  .cookies .cookies-br__first {
    display: inline;
  }
}
@media only screen and (max-device-width: 736px) {
  .cookies {
    padding: 0 120px 0 20px;
  }
  #accept_cookie_window .cookies_text {
    font-size: 11px;
    padding-right: 0;
  }
  .cookies .cookies-br__first,
  .cookies .cookies-br__second {
    display: none;
  }
}
</style>
<div id="accept_cookie_window" class="cookies">
            <p class="cookies_text">We use cookies to make sure you have the best experience on our website.<br class="cookies-br__first" />
                You can control what cookies are set on your device in your "cookies settings".<br class="cookies-br__second" />
                If you continue to use this site, you consent to our use of cookies.<span class="cookies__close" id="accept_cookie_window_close" onclick="acceptCookie()">Close</span></p>
                <script>
                document.addEventListener("DOMContentLoaded", function(event) {
                    setTimeout(function() {
                        if(window.jQuery) {
                            $(".cookies").fadeIn(300);
                        } else {
                            var element = document.getElementById("accept_cookie_window");
                            element.style.display = "block";
                        }
                    }, 3000);

                    if(window.jQuery) {
                        $(".cookies__close").click(function(){
                            $(".cookies").fadeOut(300);
                        });
                    } else {
                        var element = document.getElementById("accept_cookie_window_close");
                        element.onclick = function() {
                            var element = document.getElementById("accept_cookie_window");
                            element.style.display = "none";
                            acceptCookie();
                        };
                    }
                });
                    function acceptCookie() {
                        var date = new Date(new Date().getTime() + 7776000 * 1000);
                        document.cookie = "accept_cookie=true; path=/; expires=" + date.toUTCString();
                    }
                </script>
        </div></body></html>